import { createContext, useContext, useState, useEffect } from 'react'

const ThemeContext = createContext()

export const useTheme = () => {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}

const themes = {
  purple: {
    name: 'Purple Galaxy',
    bg: 'from-violet-900 via-purple-900 to-fuchsia-900',
    card: 'from-violet-800/60 to-fuchsia-800/60',
    border: 'border-violet-400/40',
    text: 'text-violet-300',
    accent: 'from-pink-500 to-violet-500'
  },
  neon: {
    name: 'Neon Cyber',
    bg: 'from-black via-purple-900 to-black',
    card: 'from-purple-900/80 to-pink-900/80',
    border: 'border-pink-400/60',
    text: 'text-pink-300',
    accent: 'from-pink-400 to-purple-400'
  },
  ocean: {
    name: 'Deep Ocean',
    bg: 'from-blue-900 via-indigo-900 to-cyan-900',
    card: 'from-blue-800/60 to-cyan-800/60',
    border: 'border-cyan-400/40',
    text: 'text-cyan-300',
    accent: 'from-cyan-500 to-blue-500'
  },
  forest: {
    name: 'Mystic Forest',
    bg: 'from-green-900 via-emerald-900 to-teal-900',
    card: 'from-green-800/60 to-teal-800/60',
    border: 'border-emerald-400/40',
    text: 'text-emerald-300',
    accent: 'from-emerald-500 to-teal-500'
  },
  sunset: {
    name: 'Golden Sunset',
    bg: 'from-orange-900 via-red-900 to-pink-900',
    card: 'from-orange-800/60 to-pink-800/60',
    border: 'border-orange-400/40',
    text: 'text-orange-300',
    accent: 'from-yellow-500 to-red-500'
  },
  royal: {
    name: 'Royal Gold',
    bg: 'from-yellow-900 via-amber-900 to-orange-900',
    card: 'from-yellow-800/60 to-orange-800/60',
    border: 'border-yellow-400/40',
    text: 'text-yellow-300',
    accent: 'from-yellow-500 to-orange-500'
  },
  arctic: {
    name: 'Arctic Ice',
    bg: 'from-slate-900 via-blue-900 to-indigo-900',
    card: 'from-slate-800/60 to-blue-800/60',
    border: 'border-slate-400/40',
    text: 'text-slate-300',
    accent: 'from-slate-500 to-blue-500'
  },
  cosmic: {
    name: 'Cosmic Space',
    bg: 'from-indigo-900 via-purple-900 to-blue-900',
    card: 'from-indigo-800/60 to-purple-800/60',
    border: 'border-indigo-400/40',
    text: 'text-indigo-300',
    accent: 'from-indigo-500 to-purple-500'
  }
}

export const ThemeProvider = ({ children }) => {
  const [currentTheme, setCurrentTheme] = useState('purple')

  useEffect(() => {
    const savedTheme = localStorage.getItem('quicktopup_theme')
    if (savedTheme && themes[savedTheme]) {
      setCurrentTheme(savedTheme)
    }
  }, [])

  const changeTheme = (themeName) => {
    setCurrentTheme(themeName)
    localStorage.setItem('quicktopup_theme', themeName)
  }

  const nextTheme = () => {
    const themeKeys = Object.keys(themes)
    const currentIndex = themeKeys.indexOf(currentTheme)
    const nextIndex = (currentIndex + 1) % themeKeys.length
    changeTheme(themeKeys[nextIndex])
  }

  const value = {
    currentTheme,
    theme: themes[currentTheme],
    themes,
    changeTheme,
    nextTheme
  }

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  )
}
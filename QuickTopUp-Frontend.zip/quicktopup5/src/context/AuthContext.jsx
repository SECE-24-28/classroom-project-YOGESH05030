import { createContext, useContext, useState, useEffect } from 'react'

const AuthContext = createContext()

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

const hardcodedUsers = [
  { email: 'admin@quicktopup.com', password: 'admin123', role: 'admin', name: 'Admin User' },
  { email: 'user1@topup.com', password: 'user123', role: 'user', name: 'User One' },
  { email: 'user2@topup.com', password: 'user123', role: 'user', name: 'User Two' },
  { email: 'user3@topup.com', password: 'user123', role: 'user', name: 'User Three' }
]

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const savedUser = localStorage.getItem('quicktopup_user')
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
    setLoading(false)
  }, [])

  const login = (email, password) => {
    const foundUser = hardcodedUsers.find(u => u.email === email && u.password === password)
    if (foundUser) {
      const userData = { email: foundUser.email, role: foundUser.role, name: foundUser.name }
      setUser(userData)
      localStorage.setItem('quicktopup_user', JSON.stringify(userData))
      return { success: true, user: userData }
    }
    return { success: false, message: 'Invalid credentials' }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('quicktopup_user')
  }

  const value = {
    user,
    login,
    logout,
    loading
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}
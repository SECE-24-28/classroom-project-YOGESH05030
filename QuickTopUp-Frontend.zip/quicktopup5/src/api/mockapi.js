import axios from 'axios'

// Updated MockAPI URL - replace with your actual endpoint
const BASE_URL = 'https://675c8b4071933a4e885433b8.mockapi.io'

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Plans API with better error handling
export const plansAPI = {
  getAll: () => api.get('/plans'),
  create: (plan) => api.post('/plans', plan),
  update: (id, plan) => api.put(`/plans/${id}`, plan),
  delete: (id) => api.delete(`/plans/${id}`),
}

// Recharges API
export const rechargesAPI = {
  getAll: () => api.get('/recharges'),
  create: (recharge) => api.post('/recharges', recharge),
  getByUser: (userEmail) => api.get(`/recharges?userEmail=${userEmail}`),
}

// Test connection function
export const testConnection = async () => {
  try {
    await api.get('/plans')
    return true
  } catch (error) {
    console.error('Connection test failed:', error.message)
    return false
  }
}

// Default plans data
export const defaultPlans = [
  { title: "Basic Talk Time", amount: 10, validity: "7 days", description: "Basic talk time for emergency calls" },
  { title: "Quick Chat", amount: 25, validity: "15 days", description: "Perfect for quick conversations" },
  { title: "Daily Essential", amount: 50, validity: "30 days", description: "Essential daily communication needs" },
  { title: "Weekly Wonder", amount: 75, validity: "7 days", description: "High-speed data for a week" },
  { title: "Monthly Basic", amount: 100, validity: "30 days", description: "Basic monthly plan with calls and data" },
  { title: "Student Special", amount: 149, validity: "28 days", description: "Special discount for students" },
  { title: "Data Booster", amount: 199, validity: "30 days", description: "2GB high-speed data" },
  { title: "Talk More", amount: 249, validity: "30 days", description: "Unlimited local calls" },
  { title: "Smart Connect", amount: 299, validity: "30 days", description: "4GB data + unlimited calls" },
  { title: "Family Pack", amount: 399, validity: "30 days", description: "Perfect for family usage" },
  { title: "Business Pro", amount: 499, validity: "30 days", description: "Professional business plan" },
  { title: "Data Unlimited", amount: 599, validity: "30 days", description: "Unlimited high-speed data" },
  { title: "Premium Plus", amount: 699, validity: "45 days", description: "Premium features with extended validity" },
  { title: "Super Saver", amount: 799, validity: "60 days", description: "Long validity with great benefits" },
  { title: "Ultimate Freedom", amount: 999, validity: "84 days", description: "Ultimate freedom with all benefits" },
  { title: "Yearly Basic", amount: 1499, validity: "365 days", description: "Basic yearly plan" },
  { title: "Yearly Premium", amount: 2999, validity: "365 days", description: "Premium yearly plan with unlimited benefits" },
  { title: "International Roaming", amount: 1999, validity: "30 days", description: "International roaming pack" },
  { title: "Gaming Special", amount: 399, validity: "30 days", description: "Low latency for gaming" },
  { title: "Video Streaming", amount: 449, validity: "30 days", description: "Optimized for video streaming" }
]

// Initialize with fallback to local storage
export const initializeData = async () => {
  try {
    const connected = await testConnection()
    if (connected) {
      const response = await plansAPI.getAll()
      if (response.data.length === 0) {
        for (const plan of defaultPlans) {
          await plansAPI.create(plan)
        }
      }
      return { success: true, source: 'api' }
    } else {
      // Fallback to localStorage
      const localPlans = localStorage.getItem('quicktopup_plans')
      if (!localPlans) {
        localStorage.setItem('quicktopup_plans', JSON.stringify(defaultPlans.map((plan, index) => ({ ...plan, id: index + 1 }))))
      }
      return { success: true, source: 'local' }
    }
  } catch (error) {
    console.error('Error initializing data:', error)
    return { success: false, error: error.message }
  }
}

// Local storage fallback functions
export const localPlansAPI = {
  getAll: () => {
    const plans = localStorage.getItem('quicktopup_plans')
    return { data: plans ? JSON.parse(plans) : [] }
  },
  create: (plan) => {
    const plans = JSON.parse(localStorage.getItem('quicktopup_plans') || '[]')
    const newPlan = { ...plan, id: Date.now() }
    plans.push(newPlan)
    localStorage.setItem('quicktopup_plans', JSON.stringify(plans))
    return { data: newPlan }
  },
  update: (id, plan) => {
    const plans = JSON.parse(localStorage.getItem('quicktopup_plans') || '[]')
    const index = plans.findIndex(p => p.id == id)
    if (index !== -1) {
      plans[index] = { ...plan, id }
      localStorage.setItem('quicktopup_plans', JSON.stringify(plans))
      return { data: plans[index] }
    }
    throw new Error('Plan not found')
  },
  delete: (id) => {
    const plans = JSON.parse(localStorage.getItem('quicktopup_plans') || '[]')
    const filtered = plans.filter(p => p.id != id)
    localStorage.setItem('quicktopup_plans', JSON.stringify(filtered))
    return { data: { id } }
  }
}
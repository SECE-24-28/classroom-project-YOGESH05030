import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useTheme } from '../context/ThemeContext'
import { Palette, LogOut, User, Zap, Home, Settings, History, CreditCard, Info, Menu, X } from 'lucide-react'
import { useState } from 'react'

const Navbar = () => {
  const { user, logout } = useAuth()
  const { nextTheme, theme } = useTheme()
  const navigate = useNavigate()
  const location = useLocation()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const adminNavItems = [
    { path: '/admin', label: 'Home', icon: Home },
    { path: '/admin/plans', label: 'Plans', icon: Settings },
    { path: '/admin/history', label: 'History', icon: History },
    { path: '/about', label: 'About', icon: Info },
  ]

  const userNavItems = [
    { path: '/user', label: 'Home', icon: Home },
    { path: '/user/recharge', label: 'Recharge', icon: CreditCard },
    { path: '/user/history', label: 'History', icon: History },
    { path: '/about', label: 'About', icon: Info },
  ]

  const navItems = user?.role === 'admin' ? adminNavItems : userNavItems

  return (
    <nav className={`bg-gradient-to-r ${theme.card} backdrop-blur-2xl border-b ${theme.border} sticky top-0 z-50 shadow-2xl`}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to={user?.role === 'admin' ? '/admin' : '/user'} className="flex items-center space-x-4 group">
            <div className="relative">
              <div className={`p-3 bg-gradient-to-r ${theme.accent} rounded-2xl shadow-lg group-hover:shadow-purple-500/50 transition-all`}>
                <Zap className="h-8 w-8 text-white" />
              </div>
              <div className={`absolute -inset-1 bg-gradient-to-r ${theme.accent} rounded-2xl blur opacity-30 group-hover:opacity-60 transition-opacity`}></div>
            </div>
            <div>
              <span className={`text-3xl font-black bg-gradient-to-r ${theme.accent} bg-clip-text text-transparent`}>
                QuickTopUp
              </span>
              <p className={`${theme.text} text-sm font-bold -mt-1`}>Lightning Fast Recharge</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-2">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center space-x-2 px-6 py-3 rounded-2xl font-bold transition-all transform hover:scale-105 ${
                  location.pathname === item.path
                    ? `bg-gradient-to-r ${theme.accent} text-white shadow-lg`
                    : `${theme.text} hover:text-white hover:bg-purple-800/50`
                }`}
              >
                <item.icon className="h-5 w-5" />
                <span>{item.label}</span>
              </Link>
            ))}
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            {/* Theme Toggle */}
            <button
              onClick={nextTheme}
              className={`p-3 bg-purple-800/50 hover:bg-purple-700/50 rounded-2xl border ${theme.border} transition-all transform hover:scale-105`}
            >
              <Palette className={`h-6 w-6 ${theme.text}`} />
            </button>

            {user && (
              <>
                {/* User Info - Desktop */}
                <div className={`hidden md:flex items-center space-x-4 px-6 py-3 bg-purple-800/50 rounded-2xl border ${theme.border}`}>
                  <div className={`p-2 bg-gradient-to-r ${theme.accent} rounded-xl`}>
                    <User className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <span className="text-white font-bold block">{user.name}</span>
                    <span className={`px-3 py-1 bg-gradient-to-r ${theme.accent}/20 ${theme.text} text-xs rounded-lg font-bold border ${theme.border}`}>
                      {user.role.toUpperCase()}
                    </span>
                  </div>
                </div>

                {/* Logout Button */}
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-red-500/20 to-pink-500/20 hover:from-red-500/30 hover:to-pink-500/30 border border-red-400/30 rounded-2xl text-red-400 hover:text-red-300 transition-all transform hover:scale-105"
                >
                  <LogOut className="h-5 w-5" />
                  <span className="hidden md:block font-bold">Logout</span>
                </button>

                {/* Mobile Menu Button */}
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="md:hidden p-3 bg-purple-800/50 rounded-2xl border border-purple-400/30"
                >
                  {mobileMenuOpen ? <X className="h-6 w-6 text-white" /> : <Menu className="h-6 w-6 text-white" />}
                </button>
              </>
            )}
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && user && (
          <div className="md:hidden py-4 border-t border-purple-400/30">
            <div className="space-y-2">
              {/* User Info - Mobile */}
              <div className={`flex items-center space-x-4 px-4 py-3 bg-purple-800/30 rounded-2xl mb-4 border ${theme.border}`}>
                <div className={`p-2 bg-gradient-to-r ${theme.accent} rounded-xl`}>
                  <User className="h-5 w-5 text-white" />
                </div>
                <div>
                  <span className="text-white font-bold block">{user.name}</span>
                  <span className={`px-3 py-1 bg-gradient-to-r ${theme.accent}/20 ${theme.text} text-xs rounded-lg font-bold border ${theme.border}`}>
                    {user.role.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Navigation Items - Mobile */}
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-2xl font-bold transition-all ${
                    location.pathname === item.path
                      ? `bg-gradient-to-r ${theme.accent} text-white`
                      : `${theme.text} hover:text-white hover:bg-purple-800/50`
                  }`}
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

export default Navbar
import { useState, useEffect } from 'react'
import { plansAPI, defaultPlans } from '../api/mockapi'

export const usePlans = () => {
  const [plans, setPlans] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchPlans = async () => {
    try {
      setLoading(true)
      const response = await plansAPI.getAll()
      
      if (response.data.length === 0) {
        // Seed default plans if none exist
        const promises = defaultPlans.map(plan => plansAPI.create(plan))
        await Promise.all(promises)
        const newResponse = await plansAPI.getAll()
        setPlans(newResponse.data)
      } else {
        setPlans(response.data)
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const addPlan = async (planData) => {
    try {
      const response = await plansAPI.create(planData)
      setPlans(prev => [...prev, response.data])
      return response.data
    } catch (err) {
      setError(err.message)
      throw err
    }
  }

  const updatePlan = async (id, planData) => {
    try {
      const response = await plansAPI.update(id, planData)
      setPlans(prev => prev.map(plan => plan.id === id ? response.data : plan))
      return response.data
    } catch (err) {
      setError(err.message)
      throw err
    }
  }

  const deletePlan = async (id) => {
    try {
      await plansAPI.delete(id)
      setPlans(prev => prev.filter(plan => plan.id !== id))
    } catch (err) {
      setError(err.message)
      throw err
    }
  }

  useEffect(() => {
    fetchPlans()
  }, [])

  return {
    plans,
    loading,
    error,
    addPlan,
    updatePlan,
    deletePlan,
    refetch: fetchPlans
  }
}
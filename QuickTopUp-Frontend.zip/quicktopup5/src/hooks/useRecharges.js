import { useState, useEffect } from 'react'
import { rechargesAPI } from '../api/mockapi'

export const useRecharges = (userEmail = null) => {
  const [recharges, setRecharges] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchRecharges = async () => {
    try {
      setLoading(true)
      const response = userEmail 
        ? await rechargesAPI.getByUser(userEmail)
        : await rechargesAPI.getAll()
      
      setRecharges(response.data.sort((a, b) => new Date(b.date) - new Date(a.date)))
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const addRecharge = async (rechargeData) => {
    try {
      const response = await rechargesAPI.create(rechargeData)
      setRecharges(prev => [response.data, ...prev])
      return response.data
    } catch (err) {
      setError(err.message)
      throw err
    }
  }

  const getStats = () => {
    const totalAmount = recharges.reduce((sum, recharge) => sum + recharge.amount, 0)
    const totalCount = recharges.length
    
    return {
      totalAmount,
      totalCount,
      averageAmount: totalCount > 0 ? Math.round(totalAmount / totalCount) : 0
    }
  }

  useEffect(() => {
    fetchRecharges()
  }, [userEmail])

  return {
    recharges,
    loading,
    error,
    addRecharge,
    getStats,
    refetch: fetchRecharges
  }
}
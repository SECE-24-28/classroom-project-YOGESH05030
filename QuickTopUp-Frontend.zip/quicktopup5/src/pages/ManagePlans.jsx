import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Plus, Edit, Trash2, Save, X, Zap, Star, Clock, Shield } from 'lucide-react'
import Navbar from '../components/Navbar'
import { plansAPI, localPlansAPI, testConnection, defaultPlans } from '../api/mockapi'

const ManagePlans = () => {
  const [plans, setPlans] = useState([])
  const [loading, setLoading] = useState(true)
  const [editingPlan, setEditingPlan] = useState(null)
  const [showAddForm, setShowAddForm] = useState(false)
  const [formData, setFormData] = useState({ title: '', amount: '', validity: '', description: '' })
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [useLocal, setUseLocal] = useState(false)

  useEffect(() => {
    initializePlans()
  }, [])

  const initializePlans = async () => {
    try {
      setLoading(true)
      const connected = await testConnection()
      
      if (connected) {
        const response = await plansAPI.getAll()
        if (response.data.length === 0) {
          for (const plan of defaultPlans) {
            await plansAPI.create(plan)
          }
          const newResponse = await plansAPI.getAll()
          setPlans(newResponse.data)
        } else {
          setPlans(response.data)
        }
        setUseLocal(false)
      } else {
        let localPlans = JSON.parse(localStorage.getItem('quicktopup_plans') || '[]')
        if (localPlans.length === 0) {
          localPlans = defaultPlans.map((plan, index) => ({ ...plan, id: index + 1 }))
          localStorage.setItem('quicktopup_plans', JSON.stringify(localPlans))
        }
        setPlans(localPlans)
        setUseLocal(true)
      }
    } catch (error) {
      console.error('Error:', error)
      setError('Using offline mode')
      setUseLocal(true)
      const localPlans = defaultPlans.map((plan, index) => ({ ...plan, id: index + 1 }))
      setPlans(localPlans)
      localStorage.setItem('quicktopup_plans', JSON.stringify(localPlans))
    } finally {
      setLoading(false)
    }
  }

  const handleAdd = async (e) => {
    e.preventDefault()
    try {
      const newPlan = {
        title: formData.title,
        amount: parseInt(formData.amount),
        validity: formData.validity,
        description: formData.description
      }
      
      if (useLocal) {
        const response = localPlansAPI.create(newPlan)
        setPlans([...plans, response.data])
      } else {
        const response = await plansAPI.create(newPlan)
        setPlans([...plans, response.data])
      }
      
      setFormData({ title: '', amount: '', validity: '', description: '' })
      setShowAddForm(false)
      setSuccess('Plan created successfully!')
      setTimeout(() => setSuccess(''), 3000)
    } catch (error) {
      setError('Failed to create plan')
    }
  }

  const handleEdit = async (e) => {
    e.preventDefault()
    try {
      const updatedPlan = {
        title: formData.title,
        amount: parseInt(formData.amount),
        validity: formData.validity,
        description: formData.description
      }
      
      if (useLocal) {
        const response = localPlansAPI.update(editingPlan.id, updatedPlan)
        setPlans(plans.map(plan => plan.id === editingPlan.id ? response.data : plan))
      } else {
        const response = await plansAPI.update(editingPlan.id, updatedPlan)
        setPlans(plans.map(plan => plan.id === editingPlan.id ? response.data : plan))
      }
      
      setEditingPlan(null)
      setFormData({ title: '', amount: '', validity: '', description: '' })
      setSuccess('Plan updated successfully!')
      setTimeout(() => setSuccess(''), 3000)
    } catch (error) {
      setError('Failed to update plan')
    }
  }

  const handleDelete = async (id) => {
    if (window.confirm('Delete this plan?')) {
      try {
        if (useLocal) {
          localPlansAPI.delete(id)
          setPlans(plans.filter(plan => plan.id !== id))
        } else {
          await plansAPI.delete(id)
          setPlans(plans.filter(plan => plan.id !== id))
        }
        setSuccess('Plan deleted!')
        setTimeout(() => setSuccess(''), 3000)
      } catch (error) {
        setError('Failed to delete plan')
      }
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin"></div>
            <Zap className="absolute inset-0 m-auto h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center space-x-3 mb-4"
          >
            <div className="relative">
              <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl">
                <Zap className="h-8 w-8 text-white" />
              </div>
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl blur opacity-30 animate-pulse"></div>
            </div>
            <h1 className="text-5xl font-black bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">
              PLAN MANAGER
            </h1>
          </motion.div>
          
          <div className="flex items-center justify-center space-x-4 mb-6">
            <div className={`px-4 py-2 rounded-full text-sm font-medium ${useLocal ? 'bg-yellow-500/20 text-yellow-300' : 'bg-green-500/20 text-green-300'}`}>
              {useLocal ? '⚡ OFFLINE MODE' : '🌐 ONLINE MODE'}
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="group relative px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl font-bold text-white overflow-hidden transition-all duration-300 hover:scale-105"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-pink-600 to-purple-600 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <div className="relative flex items-center space-x-2">
                <Plus className="h-5 w-5" />
                <span>CREATE PLAN</span>
              </div>
            </button>
          </div>
        </div>

        {/* Messages */}
        {success && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-6 p-4 bg-green-500/20 border-2 border-green-500/40 rounded-2xl text-green-300 text-center font-medium"
          >
            ✨ {success}
          </motion.div>
        )}

        {error && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-6 p-4 bg-yellow-500/20 border-2 border-yellow-500/40 rounded-2xl text-yellow-300 text-center font-medium"
          >
            ⚠️ {error}
          </motion.div>
        )}

        {/* Add/Edit Form */}
        {(showAddForm || editingPlan) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8 p-8 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl"
          >
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center space-x-3">
              <Star className="h-6 w-6 text-purple-400" />
              <span>{editingPlan ? 'EDIT PLAN' : 'NEW PLAN'}</span>
            </h2>
            
            <form onSubmit={editingPlan ? handleEdit : handleAdd} className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-4 py-4 bg-violet-900/40 border-2 border-violet-400/40 rounded-2xl text-white placeholder-violet-400 focus:border-pink-400 focus:outline-none"
                  placeholder="Plan Title"
                  required
                />
              </div>
              <div>
                <input
                  type="number"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="w-full px-4 py-4 bg-violet-900/40 border-2 border-violet-400/40 rounded-2xl text-white placeholder-violet-400 focus:border-pink-400 focus:outline-none"
                  placeholder="Amount (₹)"
                  required
                />
              </div>
              <div>
                <input
                  type="text"
                  value={formData.validity}
                  onChange={(e) => setFormData({ ...formData, validity: e.target.value })}
                  className="w-full px-4 py-4 bg-violet-900/40 border-2 border-violet-400/40 rounded-2xl text-white placeholder-violet-400 focus:border-pink-400 focus:outline-none"
                  placeholder="Validity (e.g., 30 days)"
                  required
                />
              </div>
              <div>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-4 py-4 bg-violet-900/40 border-2 border-violet-400/40 rounded-2xl text-white placeholder-violet-400 focus:border-pink-400 focus:outline-none"
                  placeholder="Description"
                  required
                />
              </div>
              
              <div className="md:col-span-2 flex space-x-4">
                <button
                  type="submit"
                  className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl text-white font-bold hover:scale-105 transition-transform"
                >
                  <Save className="h-4 w-4" />
                  <span>{editingPlan ? 'UPDATE' : 'SAVE'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditingPlan(null)
                    setShowAddForm(false)
                    setFormData({ title: '', amount: '', validity: '', description: '' })
                  }}
                  className="flex items-center space-x-2 px-6 py-3 bg-violet-600 rounded-2xl text-white font-bold hover:scale-105 transition-transform"
                >
                  <X className="h-4 w-4" />
                  <span>CANCEL</span>
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              className="group relative p-6 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl hover:border-pink-400/50 transition-all duration-300 hover:scale-105"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-pink-600/10 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
              
              <div className="relative">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl">
                      <Zap className="h-5 w-5 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-white">{plan.title}</h3>
                  </div>
                  
                  <div className="flex space-x-2">
                    <button
                      onClick={() => {
                        setEditingPlan(plan)
                        setFormData({
                          title: plan.title,
                          amount: plan.amount.toString(),
                          validity: plan.validity,
                          description: plan.description
                        })
                      }}
                      className="p-2 bg-blue-500/20 hover:bg-blue-500/30 rounded-xl text-blue-400 transition-colors"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(plan.id)}
                      className="p-2 bg-red-500/20 hover:bg-red-500/30 rounded-xl text-red-400 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="text-4xl font-black bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                    ₹{plan.amount}
                  </div>
                  
                  <div className="flex items-center space-x-2 text-purple-300">
                    <Clock className="h-4 w-4" />
                    <span className="font-medium">{plan.validity}</span>
                  </div>
                  
                  <div className="flex items-start space-x-2 text-gray-300">
                    <Shield className="h-4 w-4 mt-0.5 text-purple-400" />
                    <p className="text-sm leading-relaxed">{plan.description}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {plans.length === 0 && (
          <div className="text-center py-20">
            <div className="p-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full w-24 h-24 mx-auto mb-6 flex items-center justify-center">
              <Zap className="h-12 w-12 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-4">No Plans Yet</h3>
            <p className="text-gray-400 mb-6">Create your first recharge plan to get started</p>
            <button
              onClick={() => setShowAddForm(true)}
              className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl text-white font-bold hover:scale-105 transition-transform"
            >
              CREATE FIRST PLAN
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

export default ManagePlans
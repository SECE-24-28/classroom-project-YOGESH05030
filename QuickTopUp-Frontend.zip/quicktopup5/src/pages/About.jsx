import { motion } from 'framer-motion'
import { Zap, Shield, Clock, Users, Star, Award, Smartphone, Globe, Heart, CheckCircle } from 'lucide-react'
import Navbar from '../components/Navbar'

const About = () => {
  const features = [
    {
      icon: Zap,
      title: 'Lightning Fast',
      description: 'Instant recharge processing in seconds',
      gradient: 'from-yellow-500 to-orange-500'
    },
    {
      icon: Shield,
      title: 'Secure & Safe',
      description: 'Bank-level security for all transactions',
      gradient: 'from-green-500 to-emerald-500'
    },
    {
      icon: Clock,
      title: '24/7 Available',
      description: 'Round the clock service availability',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      icon: Users,
      title: 'Multi-User Support',
      description: 'Admin and employee role management',
      gradient: 'from-purple-500 to-pink-500'
    },
    {
      icon: Star,
      title: 'Premium Plans',
      description: 'Wide variety of recharge plans',
      gradient: 'from-indigo-500 to-purple-500'
    },
    {
      icon: Globe,
      title: 'All Networks',
      description: 'Support for Airtel, Jio, Vi, BSNL',
      gradient: 'from-pink-500 to-rose-500'
    }
  ]

  const stats = [
    { label: 'Happy Users', value: '10K+', icon: Users },
    { label: 'Recharges Done', value: '50K+', icon: Smartphone },
    { label: 'Success Rate', value: '99.9%', icon: CheckCircle },
    { label: 'Networks Supported', value: '4+', icon: Globe }
  ]

  const team = [
    {
      name: 'Admin User',
      role: 'System Administrator',
      description: 'Manages all platform operations and user accounts',
      avatar: '👨‍💼',
      gradient: 'from-blue-500 to-purple-500'
    },
    {
      name: 'Employee Team',
      role: 'Recharge Specialists',
      description: 'Handles customer recharge requests efficiently',
      avatar: '👥',
      gradient: 'from-green-500 to-teal-500'
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header */}
          <div className="text-center mb-16">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center space-x-4 mb-6"
            >
              <div className="relative">
                <div className="p-4 bg-gradient-to-r from-pink-500 via-purple-500 to-violet-500 rounded-full shadow-2xl">
                  <Heart className="h-12 w-12 text-white" />
                </div>
                <div className="absolute -inset-2 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full blur opacity-40 animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-6xl font-black bg-gradient-to-r from-pink-400 via-purple-400 to-violet-400 bg-clip-text text-transparent">
                  ABOUT QUICKTOPUP
                </h1>
                <p className="text-purple-300 text-xl font-bold mt-2">Your Trusted Mobile Recharge Partner</p>
              </div>
            </motion.div>
            
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-lg text-violet-200 max-w-3xl mx-auto leading-relaxed"
            >
              QuickTopUp is a revolutionary mobile recharge platform designed to provide lightning-fast, 
              secure, and convenient recharge services. Built with cutting-edge technology and user-centric design, 
              we make mobile recharging effortless for everyone.
            </motion.p>
          </div>

          {/* Stats Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16"
          >
            {stats.map((stat, index) => (
              <div
                key={stat.label}
                className="text-center p-6 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl hover:scale-105 transition-transform"
              >
                <div className="p-3 bg-gradient-to-r from-pink-500 to-violet-500 rounded-2xl w-fit mx-auto mb-4">
                  <stat.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-3xl font-black text-white mb-2">{stat.value}</div>
                <div className="text-violet-300 font-medium">{stat.label}</div>
              </div>
            ))}
          </motion.div>

          {/* Features Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="mb-16"
          >
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-white mb-4">WHY CHOOSE US?</h2>
              <p className="text-violet-300 text-lg">Discover what makes QuickTopUp the best choice for mobile recharges</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.6 + index * 0.1 }}
                  className="p-8 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl hover:border-pink-400/50 transition-all duration-300 hover:scale-105 group"
                >
                  <div className={`p-4 bg-gradient-to-r ${feature.gradient} rounded-2xl w-fit mb-6 group-hover:scale-110 transition-transform`}>
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-black text-white mb-4">{feature.title}</h3>
                  <p className="text-violet-200 leading-relaxed">{feature.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Mission Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8 }}
            className="mb-16 p-12 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl text-center"
          >
            <div className="p-4 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full w-fit mx-auto mb-8">
              <Award className="h-12 w-12 text-white" />
            </div>
            <h2 className="text-4xl font-black text-white mb-6">OUR MISSION</h2>
            <p className="text-xl text-violet-200 leading-relaxed max-w-4xl mx-auto">
              To revolutionize the mobile recharge experience by providing a seamless, secure, and lightning-fast platform 
              that empowers users to stay connected effortlessly. We believe in making technology accessible and user-friendly 
              for everyone, from individual users to enterprise teams.
            </p>
          </motion.div>

          {/* Team Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="mb-16"
          >
            <div className="text-center mb-12">
              <h2 className="text-4xl font-black text-white mb-4">MEET OUR TEAM</h2>
              <p className="text-violet-300 text-lg">The dedicated professionals behind QuickTopUp</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {team.map((member, index) => (
                <motion.div
                  key={member.name}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 1 + index * 0.2 }}
                  className="p-8 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl hover:scale-105 transition-transform text-center"
                >
                  <div className={`text-6xl mb-6 p-6 bg-gradient-to-r ${member.gradient} rounded-full w-fit mx-auto`}>
                    {member.avatar}
                  </div>
                  <h3 className="text-2xl font-black text-white mb-2">{member.name}</h3>
                  <p className="text-pink-300 font-bold mb-4">{member.role}</p>
                  <p className="text-violet-200 leading-relaxed">{member.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Technology Stack */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.1 }}
            className="p-12 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl text-center"
          >
            <div className="p-4 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full w-fit mx-auto mb-8">
              <Zap className="h-12 w-12 text-white" />
            </div>
            <h2 className="text-4xl font-black text-white mb-6">BUILT WITH MODERN TECHNOLOGY</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
              {['React', 'Vite', 'Tailwind CSS', 'Framer Motion'].map((tech, index) => (
                <div
                  key={tech}
                  className="p-4 bg-violet-900/40 border-2 border-violet-400/30 rounded-2xl hover:border-pink-400/40 transition-colors"
                >
                  <div className="text-lg font-black text-white">{tech}</div>
                </div>
              ))}
            </div>
            <p className="text-violet-200 mt-8 text-lg leading-relaxed">
              Powered by cutting-edge web technologies for optimal performance, security, and user experience.
            </p>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}

export default About
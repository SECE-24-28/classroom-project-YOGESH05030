import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Zap, History, CreditCard, TrendingUp, Smartphone, User, ArrowRight, Clock, Shield } from 'lucide-react'
import Navbar from '../components/Navbar'
import { plansAPI, rechargesAPI, localPlansAPI } from '../api/mockapi'
import { useAuth } from '../context/AuthContext'
import { useTheme } from '../context/ThemeContext'

const UserDashboard = () => {
  const { user } = useAuth()
  const { theme } = useTheme()
  const [stats, setStats] = useState({
    totalPlans: 0,
    myRecharges: 0,
    totalSpent: 0
  })
  const [recentPlans, setRecentPlans] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [user])

  const fetchData = async () => {
    try {
      let plansData, rechargesData
      
      try {
        const [plansRes, rechargesRes] = await Promise.all([
          plansAPI.getAll(),
          rechargesAPI.getByUser(user.email)
        ])
        plansData = plansRes.data
        rechargesData = rechargesRes.data
      } catch (error) {
        plansData = localPlansAPI.getAll().data
        const allRecharges = JSON.parse(localStorage.getItem('quicktopup_recharges') || '[]')
        rechargesData = allRecharges.filter(r => r.userEmail === user.email)
      }

      const totalSpent = rechargesData.reduce((sum, recharge) => sum + (recharge.amount || 0), 0)

      setStats({
        totalPlans: plansData.length,
        myRecharges: rechargesData.length,
        totalSpent
      })

      setRecentPlans(plansData.slice(0, 6))
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const dashboardCards = [
    {
      title: 'Browse Plans',
      description: 'Explore all available recharge plans',
      icon: Smartphone,
      link: '/user/recharge',
      gradient: 'from-pink-500 via-purple-500 to-violet-500',
      stats: `${stats.totalPlans} Available`,
      bgGlow: 'bg-pink-500/10'
    },
    {
      title: 'My History',
      description: 'View your recharge transaction history',
      icon: History,
      link: '/user/history',
      gradient: 'from-green-500 via-emerald-500 to-teal-500',
      stats: `${stats.myRecharges} Recharges`,
      bgGlow: 'bg-green-500/10'
    }
  ]

  const statsCards = [
    {
      title: 'Available Plans',
      value: stats.totalPlans,
      icon: Smartphone,
      gradient: 'from-pink-500 to-violet-500',
      bgGlow: 'bg-pink-500/10'
    },
    {
      title: 'My Recharges',
      value: stats.myRecharges,
      icon: CreditCard,
      gradient: 'from-green-500 to-emerald-500',
      bgGlow: 'bg-green-500/10'
    },
    {
      title: 'Total Spent',
      value: `₹${stats.totalSpent}`,
      icon: TrendingUp,
      gradient: 'from-purple-500 to-fuchsia-500',
      bgGlow: 'bg-purple-500/10'
    }
  ]

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin"></div>
            <User className="absolute inset-0 m-auto h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.bg}`}>
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header with Background */}
          <div className="relative text-center mb-12 overflow-hidden rounded-3xl">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-900/90 via-pink-900/90 to-violet-900/90"></div>
            <div className="absolute inset-0 opacity-30">
              <img 
                src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=1200&h=300&fit=crop&crop=center" 
                alt="Mobile technology" 
                className="w-full h-full object-cover"
              />
            </div>
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative z-10 py-12 px-8"
            >
              <div className="inline-flex items-center space-x-4 mb-6">
                <div className="relative">
                  <div className="p-4 bg-gradient-to-r from-pink-500 via-purple-500 to-violet-500 rounded-full shadow-2xl">
                    <User className="h-10 w-10 text-white" />
                  </div>
                  <div className="absolute -inset-2 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full blur opacity-40 animate-pulse"></div>
                </div>
                <div>
                  <h1 className="text-5xl font-black bg-gradient-to-r from-pink-400 via-purple-400 to-violet-400 bg-clip-text text-transparent">
                    Welcome, {user?.name}
                  </h1>
                  <p className="text-purple-300 text-xl font-bold mt-2">User Dashboard</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {statsCards.map((stat, index) => (
              <motion.div
                key={stat.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`relative p-6 bg-gradient-to-br ${theme.card} backdrop-blur-xl border-2 ${theme.border} rounded-3xl hover:border-pink-400/50 transition-all duration-300 group overflow-hidden hover:scale-105`}
              >
                <div className={`absolute inset-0 ${stat.bgGlow} opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl`}></div>
                
                <div className="relative flex items-center justify-between">
                  <div>
                    <p className={`${theme.text} text-sm font-medium mb-2`}>{stat.title}</p>
                    <p className="text-4xl font-black text-white">{stat.value}</p>
                  </div>
                  <div className={`p-3 bg-gradient-to-r ${stat.gradient} rounded-2xl shadow-lg`}>
                    <stat.icon className="h-8 w-8 text-white" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Action Cards with Images */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {dashboardCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                className="group relative overflow-hidden"
              >
                <Link
                  to={card.link}
                  className={`block bg-gradient-to-br ${theme.card} backdrop-blur-xl border-2 ${theme.border} rounded-3xl hover:border-pink-400/50 transition-all duration-300 hover:scale-105 overflow-hidden`}
                >
                  <div className={`absolute inset-0 ${card.bgGlow} opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl`}></div>
                  
                  {/* Card Image */}
                  <div className="relative h-32 overflow-hidden">
                    <img 
                      src={index === 0 ? "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=400&h=200&fit=crop&crop=center" : "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=200&fit=crop&crop=center"}
                      alt={card.title}
                      className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <div className="absolute top-4 right-4">
                      <span className={`px-3 py-1 bg-black/50 backdrop-blur-sm rounded-xl ${theme.text} font-bold text-xs border border-white/20`}>
                        {card.stats}
                      </span>
                    </div>
                  </div>
                  
                  <div className="relative p-6">
                    <div className="flex items-center mb-4">
                      <div className={`p-3 bg-gradient-to-r ${card.gradient} rounded-2xl shadow-lg mr-4`}>
                        <card.icon className="h-6 w-6 text-white" />
                      </div>
                      <h3 className="text-xl font-black text-white group-hover:text-pink-300 transition-colors">
                        {card.title}
                      </h3>
                    </div>
                    
                    <p className={`${theme.text} leading-relaxed mb-4`}>{card.description}</p>
                    
                    <div className="flex items-center text-pink-300 font-bold">
                      <span>Access Now</span>
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Quick Plans Preview with Background */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className={`relative bg-gradient-to-br ${theme.card} backdrop-blur-xl border-2 ${theme.border} rounded-3xl p-8 overflow-hidden`}
          >
            <div className="absolute top-0 right-0 w-64 h-32 opacity-20">
              <img 
                src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=300&h=150&fit=crop&crop=center" 
                alt="Mobile plans" 
                className="w-full h-full object-cover rounded-2xl"
              />
            </div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-3">
                  <svg className={`h-8 w-8 ${theme.text}`} viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2L13.09 8.26L20 9L13.09 9.74L12 16L10.91 9.74L4 9L10.91 8.26L12 2Z"/>
                    <path d="M19 15L20.09 18.26L24 19L20.09 19.74L19 23L17.91 19.74L14 19L17.91 18.26L19 15Z"/>
                    <path d="M5 15L6.09 18.26L10 19L6.09 19.74L5 23L3.91 19.74L0 19L3.91 18.26L5 15Z"/>
                  </svg>
                  <h2 className="text-2xl font-black text-white">POPULAR PLANS</h2>
                </div>
                <Link
                  to="/user/recharge"
                  className={`px-6 py-3 bg-gradient-to-r ${theme.accent} rounded-2xl text-white font-bold hover:scale-105 transition-transform`}
                >
                  View All Plans
                </Link>
              </div>
            </div>
            
            <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentPlans.map((plan, index) => (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: 0.6 + index * 0.1 }}
                  className={`relative p-6 bg-violet-900/40 border-2 ${theme.border} rounded-2xl hover:border-pink-400/40 transition-all group overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 w-16 h-16 opacity-30">
                    <img 
                      src="https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=100&h=100&fit=crop&crop=center" 
                      alt="Mobile" 
                      className="w-full h-full object-cover rounded-xl"
                    />
                  </div>
                  <div className="relative z-10 flex items-center space-x-3 mb-4">
                    <div className="p-2 bg-gradient-to-r from-pink-500 to-violet-500 rounded-xl">
                      <svg className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M8,5.14V19.14L19,12.14L8,5.14Z"/>
                        <circle cx="5" cy="12" r="3"/>
                      </svg>
                    </div>
                    <h3 className="font-bold text-white group-hover:text-pink-400 transition-colors">{plan.title}</h3>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-3xl font-black bg-gradient-to-r from-pink-400 to-violet-400 bg-clip-text text-transparent">
                      ₹{plan.amount}
                    </p>
                    <div className={`flex items-center space-x-2 ${theme.text}`}>
                      <svg className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M16.2,16.2L11,13V7H12.5V12.2L17,14.9L16.2,16.2Z"/>
                      </svg>
                      <span className="text-sm font-medium">{plan.validity}</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <svg className="h-4 w-4 mt-0.5 text-violet-400" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M10,17L6,13L7.41,11.59L10,14.17L16.59,7.58L18,9L10,17Z"/>
                      </svg>
                      <p className={`text-xs ${theme.text} leading-relaxed`}>{plan.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}

export default UserDashboard
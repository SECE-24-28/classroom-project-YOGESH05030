import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Smartphone, CreditCard, CheckCircle, Zap, Clock, Shield, Star, Wifi, Download, Receipt } from 'lucide-react'
import Navbar from '../components/Navbar'
import { plansAPI, rechargesAPI, localPlansAPI } from '../api/mockapi'
import { useAuth } from '../context/AuthContext'
import { useTheme } from '../context/ThemeContext'

const RechargePage = () => {
  const { user } = useAuth()
  const { theme } = useTheme()
  const [plans, setPlans] = useState([])
  const [selectedPlan, setSelectedPlan] = useState(null)
  const [selectedProvider, setSelectedProvider] = useState(null)
  const [selectedPayment, setSelectedPayment] = useState(null)
  const [mobileNumber, setMobileNumber] = useState('')
  const [loading, setLoading] = useState(true)
  const [recharging, setRecharging] = useState(false)
  const [success, setSuccess] = useState(false)
  const [paymentDetails, setPaymentDetails] = useState(null)
  const [filter, setFilter] = useState('all')

  const providers = [
    { 
      id: 'airtel', 
      name: 'Airtel', 
      color: 'from-red-500 to-red-600', 
      logo: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA2MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHJ4PSI4IiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiNFNUU3RUIiLz4KICA8cmVjdCB4PSI0IiB5PSI0IiB3aWR0aD0iNTIiIGhlaWdodD0iMzIiIHJ4PSI2IiBmaWxsPSIjRUQzNzQzIi8+CiAgPHBhdGggZD0iTTEyIDEyaDhsLTQgOGgtNGw0LTh6IiBmaWxsPSIjRkZGRkZGIi8+CiAgPHBhdGggZD0iTTE2IDIwaDEybC0yIDRIMTZsLTItNGgyeiIgZmlsbD0iI0ZGRkZGRiIvPgogIDx0ZXh0IHg9IjI4IiB5PSIxOCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjEwIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0ZGRkZGRiI+QWlydGVsPC90ZXh0PgogIDx0ZXh0IHg9IjI4IiB5PSIyOCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjgiIGZpbGw9IiNGRkZGRkYiPjVHPC90ZXh0Pgo8L3N2Zz4K',
      image: 'https://images.unsplash.com/photo-1611348586804-61bf6c080437?w=300&h=200&fit=crop&crop=center'
    },
    { 
      id: 'jio', 
      name: 'Jio', 
      color: 'from-blue-500 to-blue-600', 
      logo: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA2MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHJ4PSI4IiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiNFNUU3RUIiLz4KICA8cmVjdCB4PSI0IiB5PSI0IiB3aWR0aD0iNTIiIGhlaWdodD0iMzIiIHJ4PSI2IiBmaWxsPSIjMDA3REZGIi8+CiAgPGNpcmNsZSBjeD0iMTUiIGN5PSIxNSIgcj0iNiIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjRkZGRkZGIiBzdHJva2Utd2lkdGg9IjIiLz4KICA8Y2lyY2xlIGN4PSIxNSIgY3k9IjE1IiByPSIyIiBmaWxsPSIjRkZGRkZGIi8+CiAgPHRleHQgeD0iMjgiIHk9IjE4IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTIiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjRkZGRkZGIj5KaW88L3RleHQ+CiAgPHRleHQgeD0iMjgiIHk9IjI4IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iOCIgZmlsbD0iI0ZGRkZGRiI+NUc8L3RleHQ+Cjwvc3ZnPgo=',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=300&h=200&fit=crop&crop=center'
    },
    { 
      id: 'vi', 
      name: 'Vi', 
      color: 'from-purple-500 to-purple-600', 
      logo: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA2MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHJ4PSI4IiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiNFNUU3RUIiLz4KICA8cmVjdCB4PSI0IiB5PSI0IiB3aWR0aD0iNTIiIGhlaWdodD0iMzIiIHJ4PSI2IiBmaWxsPSIjNjYzM0ZGIi8+CiAgPHBhdGggZD0iTTEwIDEyaDEwdjE2SDEwVjEyeiIgZmlsbD0iI0ZGRkZGRiIgb3BhY2l0eT0iMC4zIi8+CiAgPHBhdGggZD0iTTEyIDEwaDZ2MjBoLTZWMTB6IiBmaWxsPSIjRkZGRkZGIi8+CiAgPHRleHQgeD0iMjgiIHk9IjE4IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTQiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjRkZGRkZGIj5WaTwvdGV4dD4KICA8dGV4dCB4PSIyOCIgeT0iMjgiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSI4IiBmaWxsPSIjRkZGRkZGIj40RzwvdGV4dD4KPC9zdmc+Cg==',
      image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=300&h=200&fit=crop&crop=center'
    },
    { 
      id: 'bsnl', 
      name: 'BSNL', 
      color: 'from-green-500 to-green-600', 
      logo: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA2MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHJ4PSI4IiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiNFNUU3RUIiLz4KICA8cmVjdCB4PSI0IiB5PSI0IiB3aWR0aD0iNTIiIGhlaWdodD0iMzIiIHJ4PSI2IiBmaWxsPSIjMDA4MDQ2Ii8+CiAgPHBhdGggZD0iTTEwIDEwaDEydjIwSDEwVjEweiIgZmlsbD0iI0ZGRkZGRiIgb3BhY2l0eT0iMC4yIi8+CiAgPHBhdGggZD0iTTEyIDEyaDh2MTZoLThWMTJ6IiBmaWxsPSIjRkZGRkZGIi8+CiAgPHRleHQgeD0iMjgiIHk9IjE4IiBmb250LWZhbWlseT0iQXJpYWwiIGZvbnQtc2l6ZT0iMTAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjRkZGRkZGIj5CU05MPC90ZXh0PgogIDx0ZXh0IHg9IjI4IiB5PSIyOCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjgiIGZpbGw9IiNGRkZGRkYiPjRHPC90ZXh0Pgo8L3N2Zz4K',
      image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=300&h=200&fit=crop&crop=center'
    }
  ]

  const paymentMethods = [
    {
      id: 'gpay',
      name: 'Google Pay',
      logo: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA2MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHJ4PSI4IiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiNFNUU3RUIiIHN0cm9rZS13aWR0aD0iMSIvPgogIDxyZWN0IHg9IjQiIHk9IjQiIHdpZHRoPSI1MiIgaGVpZ2h0PSIzMiIgcng9IjYiIGZpbGw9IiM0Mjg1RjQiLz4KICA8Y2lyY2xlIGN4PSIxNSIgY3k9IjIwIiByPSI4IiBmaWxsPSIjRkZGRkZGIiBvcGFjaXR5PSIwLjIiLz4KICA8Y2lyY2xlIGN4PSIxNSIgY3k9IjIwIiByPSI0IiBmaWxsPSIjRkZGRkZGIi8+CiAgPHRleHQgeD0iMjgiIHk9IjE4IiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iOCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IiNGRkZGRkYiPkdvb2dsZTwvdGV4dD4KICA8dGV4dCB4PSIyOCIgeT0iMjYiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSI4IiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0ZGRkZGRiI+UGF5PC90ZXh0Pgo8L3N2Zz4K',
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 'phonepe',
      name: 'PhonePe',
      logo: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA2MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHJ4PSI4IiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiNFNUU3RUIiIHN0cm9rZS13aWR0aD0iMSIvPgogIDxyZWN0IHg9IjQiIHk9IjQiIHdpZHRoPSI1MiIgaGVpZ2h0PSIzMiIgcng9IjYiIGZpbGw9IiM1RjI1OUYiLz4KICA8Y2lyY2xlIGN4PSIxNSIgY3k9IjIwIiByPSI4IiBmaWxsPSIjRkZGRkZGIiBvcGFjaXR5PSIwLjIiLz4KICA8cGF0aCBkPSJNMTEgMTZMMTkgMjBMMTEgMjRWMTZaIiBmaWxsPSIjRkZGRkZGIi8+CiAgPHRleHQgeD0iMjgiIHk9IjE4IiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iOCIgZm9udC13ZWlnaHQ9ImJvbGQiIGZpbGw9IiNGRkZGRkYiPlBob25lPC90ZXh0PgogIDx0ZXh0IHg9IjI4IiB5PSIyNiIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjgiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjRkZGRkZGIj5QZTwvdGV4dD4KPC9zdmc+Cg==',
      color: 'from-purple-500 to-purple-600'
    },
    {
      id: 'paytm',
      name: 'Paytm',
      logo: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA2MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHJ4PSI4IiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiNFNUU3RUIiIHN0cm9rZS13aWR0aD0iMSIvPgogIDxyZWN0IHg9IjQiIHk9IjQiIHdpZHRoPSI1MiIgaGVpZ2h0PSIzMiIgcng9IjYiIGZpbGw9IiMwMEJBRjIiLz4KICA8Y2lyY2xlIGN4PSIxNSIgY3k9IjIwIiByPSI4IiBmaWxsPSIjRkZGRkZGIiBvcGFjaXR5PSIwLjIiLz4KICA8cGF0aCBkPSJNMTEgMTZIMTlWMjRIMTFWMTZaIiBmaWxsPSIjRkZGRkZGIi8+CiAgPHBhdGggZD0iTTEzIDE4SDE3VjIySDEzVjE4WiIgZmlsbD0iIzAwQkFGMiIvPgogIDx0ZXh0IHg9IjI4IiB5PSIxOCIgZm9udC1mYW1pbHk9IkFyaWFsLCBzYW5zLXNlcmlmIiBmb250LXNpemU9IjgiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjRkZGRkZGIj5QYXl0bTwvdGV4dD4KICA8dGV4dCB4PSIyOCIgeT0iMjYiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSI2IiBmaWxsPSIjRkZGRkZGIj5XYWxsZXQ8L3RleHQ+Cjwvc3ZnPgo=',
      color: 'from-cyan-500 to-blue-500'
    },
    {
      id: 'upi',
      name: 'UPI Apps',
      logo: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA2MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iNjAiIGhlaWdodD0iNDAiIHJ4PSI4IiBmaWxsPSIjRkZGRkZGIiBzdHJva2U9IiNFNUU3RUIiIHN0cm9rZS13aWR0aD0iMSIvPgogIDxyZWN0IHg9IjQiIHk9IjQiIHdpZHRoPSI1MiIgaGVpZ2h0PSIzMiIgcng9IjYiIGZpbGw9IiNGRjY5MDAiLz4KICA8Y2lyY2xlIGN4PSIxNSIgY3k9IjIwIiByPSI4IiBmaWxsPSIjRkZGRkZGIiBvcGFjaXR5PSIwLjIiLz4KICA8cGF0aCBkPSJNMTEgMTZIMTlWMjBIMTVWMjRIMTFWMTZaIiBmaWxsPSIjRkZGRkZGIi8+CiAgPHRleHQgeD0iMjgiIHk9IjE4IiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iMTAiIGZvbnQtd2VpZ2h0PSJib2xkIiBmaWxsPSIjRkZGRkZGIj5VUEk8L3RleHQ+CiAgPHRleHQgeD0iMjgiIHk9IjI2IiBmb250LWZhbWlseT0iQXJpYWwsIHNhbnMtc2VyaWYiIGZvbnQtc2l6ZT0iNiIgZmlsbD0iI0ZGRkZGRiI+QXBwczwvdGV4dD4KPC9zdmc+Cg==',
      color: 'from-orange-500 to-red-500'
    }
  ]

  useEffect(() => {
    fetchPlans()
  }, [])

  const fetchPlans = async () => {
    try {
      let plansData
      try {
        const response = await plansAPI.getAll()
        plansData = response.data
      } catch (error) {
        plansData = localPlansAPI.getAll().data
      }
      setPlans(plansData)
    } catch (error) {
      console.error('Error fetching plans:', error)
    } finally {
      setLoading(false)
    }
  }

  const validateMobile = (number) => {
    const mobileRegex = /^[6-9]\d{9}$/
    return mobileRegex.test(number)
  }

  const handleRecharge = async () => {
    if (!selectedPlan || !mobileNumber || !selectedProvider || !selectedPayment) {
      alert('Please select provider, plan, payment method and enter mobile number')
      return
    }

    if (!validateMobile(mobileNumber)) {
      alert('Please enter a valid 10-digit mobile number starting with 6, 7, 8, or 9')
      return
    }

    setRecharging(true)
    
    try {
      const transactionId = `TXN${Date.now()}`
      const rechargeData = {
        userEmail: user.email,
        mobile: mobileNumber,
        provider: selectedProvider.name,
        paymentMethod: selectedPayment.name,
        planTitle: selectedPlan.title,
        amount: selectedPlan.amount,
        validity: selectedPlan.validity,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toLocaleTimeString(),
        transactionId,
        status: 'Success'
      }

      try {
        await rechargesAPI.create(rechargeData)
      } catch (error) {
        const recharges = JSON.parse(localStorage.getItem('quicktopup_recharges') || '[]')
        recharges.push({ ...rechargeData, id: Date.now() })
        localStorage.setItem('quicktopup_recharges', JSON.stringify(recharges))
      }

      setPaymentDetails(rechargeData)
      setSuccess(true)
      setMobileNumber('')
      setSelectedPlan(null)
      setSelectedProvider(null)
      
    } catch (error) {
      console.error('Error processing recharge:', error)
      alert('Failed to process recharge. Please try again.')
    } finally {
      setRecharging(false)
    }
  }

  const downloadReceipt = () => {
    if (!paymentDetails) return
    
    const receiptContent = `
QUICKTOPUP RECHARGE RECEIPT
============================
Transaction ID: ${paymentDetails.transactionId}
Date: ${paymentDetails.date}
Time: ${paymentDetails.time}
Mobile: ${paymentDetails.mobile}
Provider: ${paymentDetails.provider}
Plan: ${paymentDetails.planTitle}
Amount: ₹${paymentDetails.amount}
Validity: ${paymentDetails.validity}
Status: ${paymentDetails.status}
User: ${paymentDetails.userEmail}
============================
Thank you for using QuickTopUp!
    `
    
    const blob = new Blob([receiptContent], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `Receipt_${paymentDetails.transactionId}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  const filteredPlans = plans.filter(plan => {
    if (filter === 'all') return true
    if (filter === 'popular') return plan.amount >= 100 && plan.amount <= 500
    if (filter === 'data') return plan.description.toLowerCase().includes('data')
    if (filter === 'talk') return plan.description.toLowerCase().includes('call') || plan.description.toLowerCase().includes('talk')
    return true
  })

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-24 h-24 border-4 border-pink-300 border-t-pink-600 rounded-full animate-spin"></div>
            <Smartphone className="absolute inset-0 m-auto h-10 w-10 text-pink-400" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.bg}`}>
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header with Background Image */}
          <div className="relative text-center mb-12 overflow-hidden rounded-3xl">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-900/90 via-blue-900/90 to-violet-900/90 backdrop-blur-sm"></div>
            <div className="absolute inset-0 opacity-20">
              <img 
                src="https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=1200&h=400&fit=crop&crop=center" 
                alt="Mobile phones" 
                className="w-full h-full object-cover"
              />
            </div>
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative z-10 py-16 px-8"
            >
              <div className="inline-flex items-center space-x-4 mb-6">
                <div className="relative">
                  <div className="p-4 bg-gradient-to-r from-pink-500 via-purple-500 to-violet-500 rounded-full shadow-2xl">
                    <Smartphone className="h-12 w-12 text-white" />
                  </div>
                  <div className="absolute -inset-2 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full blur opacity-40 animate-pulse"></div>
                </div>
                <div>
                  <h1 className="text-6xl font-black bg-gradient-to-r from-pink-400 via-purple-400 to-violet-400 bg-clip-text text-transparent">
                    INSTANT RECHARGE
                  </h1>
                  <p className="text-purple-300 text-xl font-bold mt-2">Lightning Fast Mobile Top-Up</p>
                </div>
              </div>
            </motion.div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
            {/* Recharge Form */}
            <div className="xl:col-span-1">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="sticky top-8 p-8 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-2xl border-2 border-violet-400/40 rounded-3xl shadow-2xl"
              >
                <div className="text-center mb-8">
                  <div className="p-4 bg-gradient-to-r from-pink-500 to-violet-500 rounded-2xl w-fit mx-auto mb-4">
                    <svg className="h-8 w-8 text-white" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M20,8H4V6C4,4.89 4.89,4 6,4H18C19.11,4 20,4.89 20,6V8M20,8V18C20,19.11 19.11,20 18,20H6C4.89,20 4,19.11 4,18V8H20M16,12V14H8V12H16Z"/>
                      <circle cx="12" cy="13" r="1.5"/>
                      <path d="M7,10H9V11H7V10M15,10H17V11H15V10Z"/>
                    </svg>
                  </div>
                  <h2 className="text-2xl font-black text-white mb-2">RECHARGE NOW</h2>
                  <p className="text-violet-300">Enter details below</p>
                </div>
                
                <div className="space-y-6">
                  {/* Provider Selection */}
                  <div>
                    <label className="block text-violet-300 font-bold mb-4 text-lg">
                      Select Provider
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {providers.map((provider) => (
                        <button
                          key={provider.id}
                          onClick={() => setSelectedProvider(provider)}
                          className={`relative p-4 rounded-2xl border-2 transition-all transform hover:scale-105 overflow-hidden ${
                            selectedProvider?.id === provider.id
                              ? `bg-gradient-to-r ${provider.color} border-white text-white shadow-lg`
                              : 'bg-violet-900/30 border-violet-400/30 text-violet-300 hover:border-violet-300'
                          }`}
                        >
                          <div className="absolute inset-0 opacity-10">
                            <img src={provider.image} alt={provider.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="relative z-10">
                            <img src={provider.logo} alt={provider.name} className="w-12 h-8 mx-auto mb-2 rounded" />
                            <div className="text-sm font-bold">{provider.name}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Mobile Number */}
                  <div>
                    <label className="block text-violet-300 font-bold mb-3 text-lg">
                      Mobile Number
                    </label>
                    <div className="relative">
                      <svg className="absolute left-4 top-1/2 transform -translate-y-1/2 h-6 w-6 text-violet-400" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17,19H7V5H17M17,1H7C5.89,1 5,1.89 5,3V21C5,22.11 5.89,23 7,23H17C18.11,23 19,22.11 19,21V3C19,1.89 18.11,1 17,1Z"/>
                        <path d="M9,7H15V9H9V7M9,11H13V13H9V11Z"/>
                      </svg>
                      <input
                        type="tel"
                        value={mobileNumber}
                        onChange={(e) => setMobileNumber(e.target.value)}
                        className="w-full pl-14 pr-4 py-4 bg-violet-900/40 border-2 border-violet-400/40 rounded-2xl text-white text-lg placeholder-violet-400 focus:border-pink-400 focus:outline-none transition-all"
                        placeholder="Enter 10-digit number"
                        maxLength="10"
                      />
                    </div>
                    {mobileNumber && !validateMobile(mobileNumber) && (
                      <p className="text-red-400 text-sm mt-2 font-medium">Invalid mobile number format</p>
                    )}
                  </div>

                  {/* Selected Plan */}
                  {selectedPlan && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="p-6 bg-gradient-to-r from-pink-500/20 to-violet-500/20 rounded-2xl border-2 border-pink-400/40"
                    >
                      <h3 className="font-black text-white mb-4 text-lg">SELECTED PLAN</h3>
                      <div className="space-y-3">
                        <p className="text-violet-200 font-bold">{selectedPlan.title}</p>
                        <p className="text-3xl font-black bg-gradient-to-r from-pink-400 to-violet-400 bg-clip-text text-transparent">
                          ₹{selectedPlan.amount}
                        </p>
                        <div className="flex items-center space-x-2 text-violet-300">
                          <Clock className="h-4 w-4" />
                          <span className="font-medium">{selectedPlan.validity}</span>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* Payment Method Selection */}
                  <div>
                    <label className="block text-violet-300 font-bold mb-4 text-lg">
                      Payment Method
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {paymentMethods.map((method) => (
                        <button
                          key={method.id}
                          onClick={() => setSelectedPayment(method)}
                          className={`p-3 rounded-2xl border-2 transition-all transform hover:scale-105 ${
                            selectedPayment?.id === method.id
                              ? `bg-gradient-to-r ${method.color} border-white text-white shadow-lg`
                              : 'bg-violet-900/30 border-violet-400/30 text-violet-300 hover:border-violet-300'
                          }`}
                        >
                          <img src={method.logo} alt={method.name} className="w-12 h-8 mx-auto mb-1 rounded" />
                          <div className="text-xs font-bold">{method.name}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Recharge Button */}
                  <button
                    onClick={handleRecharge}
                    disabled={!selectedPlan || !mobileNumber || !validateMobile(mobileNumber) || !selectedProvider || !selectedPayment || recharging}
                    className="w-full py-4 px-6 bg-gradient-to-r from-pink-500 via-purple-500 to-violet-500 hover:from-pink-600 hover:via-purple-600 hover:to-violet-600 text-white font-black text-lg rounded-2xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-2xl hover:shadow-pink-500/25 transform hover:scale-105 cursor-pointer"
                  >
                    {recharging ? (
                      <div className="flex items-center justify-center space-x-3">
                        <div className="animate-spin rounded-full h-6 w-6 border-2 border-white border-t-transparent"></div>
                        <span>PROCESSING...</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center space-x-3">
                        <Zap className="h-6 w-6" />
                        <span>RECHARGE NOW</span>
                      </div>
                    )}
                  </button>
                </div>
              </motion.div>
            </div>

            {/* Plans Grid */}
            <div className="xl:col-span-3">
              {/* Filter Buttons */}
              <div className="flex flex-wrap gap-4 mb-8">
                {[
                  { key: 'all', label: 'All Plans', icon: Zap },
                  { key: 'popular', label: 'Popular', icon: Star },
                  { key: 'data', label: 'Data Plans', icon: Wifi },
                  { key: 'talk', label: 'Talk Plans', icon: Smartphone }
                ].map(({ key, label, icon: Icon }) => (
                  <button
                    key={key}
                    onClick={() => setFilter(key)}
                    className={`flex items-center space-x-2 px-6 py-3 rounded-2xl font-bold transition-all transform hover:scale-105 ${
                      filter === key
                        ? 'bg-gradient-to-r from-pink-500 to-violet-500 text-white shadow-lg'
                        : 'bg-violet-800/40 text-violet-300 hover:bg-violet-700/50 border-2 border-violet-400/40'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span>{label}</span>
                  </button>
                ))}
              </div>

              {/* Plans Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPlans.map((plan, index) => (
                  <motion.div
                    key={plan.id}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    onClick={() => setSelectedPlan(plan)}
                    className={`relative p-6 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 rounded-3xl cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-violet-500/25 group overflow-hidden ${
                      selectedPlan?.id === plan.id
                        ? 'border-pink-400 bg-gradient-to-br from-pink-500/20 to-violet-500/20 scale-105 shadow-2xl shadow-pink-500/25'
                        : 'border-violet-400/40 hover:border-pink-400/50'
                    }`}
                  >
                    <div className="absolute top-0 right-0 w-20 h-20 opacity-20">
                      <img 
                        src="https://images.unsplash.com/photo-1607706189992-eae578626c86?w=100&h=100&fit=crop&crop=center" 
                        alt="Mobile plan" 
                        className="w-full h-full object-cover rounded-2xl"
                      />
                    </div>
                    {selectedPlan?.id === plan.id && (
                      <div className="absolute -top-2 -right-2 p-2 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full z-20">
                        <CheckCircle className="h-6 w-6 text-white" />
                      </div>
                    )}

                    <div className="relative z-10 flex items-center justify-between mb-6">
                      <div className="flex items-center space-x-3">
                        <div className="p-3 bg-gradient-to-r from-pink-500 to-violet-500 rounded-2xl">
                          <svg className="h-6 w-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 2L13.09 8.26L20 9L13.09 9.74L12 16L10.91 9.74L4 9L10.91 8.26L12 2Z"/>
                            <path d="M19 15L20.09 18.26L24 19L20.09 19.74L19 23L17.91 19.74L14 19L17.91 18.26L19 15Z"/>
                            <path d="M5 15L6.09 18.26L10 19L6.09 19.74L5 23L3.91 19.74L0 19L3.91 18.26L5 15Z"/>
                          </svg>
                        </div>
                        <h3 className="text-xl font-black text-white group-hover:text-pink-300 transition-colors">
                          {plan.title}
                        </h3>
                      </div>
                      {plan.amount >= 500 && (
                        <div className="px-3 py-1 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full">
                          <span className="text-xs font-black text-black">PREMIUM</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="relative z-10 space-y-4">
                      <p className="text-5xl font-black bg-gradient-to-r from-pink-400 via-purple-400 to-violet-400 bg-clip-text text-transparent">
                        ₹{plan.amount}
                      </p>
                      
                      <div className="flex items-center space-x-2 text-violet-300">
                        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                        </svg>
                        <span className="font-bold text-lg">{plan.validity}</span>
                      </div>
                      
                      <div className="flex items-start space-x-2">
                        <svg className="h-5 w-5 mt-1 text-violet-400" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12,1L3,5V11C3,16.55 6.84,21.74 12,23C17.16,21.74 21,16.55 21,11V5L12,1M12,7C13.4,7 14.8,8.6 14.8,10V11H16V18H8V11H9.2V10C9.2,8.6 10.6,7 12,7M12,8.2C11.2,8.2 10.4,8.7 10.4,10V11H13.6V10C13.6,8.7 12.8,8.2 12,8.2Z"/>
                        </svg>
                        <p className="text-violet-200 leading-relaxed font-medium">{plan.description}</p>
                      </div>

                      <button className="relative z-10 w-full py-3 bg-gradient-to-r from-violet-600/50 to-pink-600/50 hover:from-violet-500 hover:to-pink-500 rounded-2xl text-white font-bold transition-all transform hover:scale-105 flex items-center justify-center space-x-2">
                        <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M9,20.42L2.79,14.21L5.62,11.38L9,14.77L18.88,4.88L21.71,7.71L9,20.42Z"/>
                        </svg>
                        <span>SELECT PLAN</span>
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* Success Modal with Payment Details */}
          {success && paymentDetails && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 backdrop-blur-sm p-4"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="bg-gradient-to-br from-violet-800 to-fuchsia-800 rounded-3xl p-8 max-w-md w-full border-2 border-violet-400/40 shadow-2xl"
              >
                <div className="text-center mb-6">
                  <div className="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-gradient-to-r from-green-400 to-emerald-400 mb-6">
                    <CheckCircle className="h-10 w-10 text-white" />
                  </div>
                  <h3 className="text-3xl font-black text-white mb-2">PAYMENT SUCCESS!</h3>
                  <p className="text-violet-200 text-lg font-medium">Recharge completed successfully</p>
                </div>

                {/* Payment Details */}
                <div className="bg-violet-900/50 rounded-2xl p-6 mb-6 border-2 border-violet-400/30">
                  <div className="flex items-center space-x-2 mb-4">
                    <Receipt className="h-6 w-6 text-violet-400" />
                    <h4 className="text-xl font-black text-white">PAYMENT DETAILS</h4>
                  </div>
                  
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-violet-300 font-medium">Transaction ID:</span>
                      <span className="text-white font-bold">{paymentDetails.transactionId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-violet-300 font-medium">Mobile:</span>
                      <span className="text-white font-bold">{paymentDetails.mobile}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-violet-300 font-medium">Provider:</span>
                      <span className="text-white font-bold">{paymentDetails.provider}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-violet-300 font-medium">Payment:</span>
                      <span className="text-white font-bold">{paymentDetails.paymentMethod}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-violet-300 font-medium">Plan:</span>
                      <span className="text-white font-bold">{paymentDetails.planTitle}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-violet-300 font-medium">Amount:</span>
                      <span className="text-green-400 font-black text-lg">₹{paymentDetails.amount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-violet-300 font-medium">Validity:</span>
                      <span className="text-white font-bold">{paymentDetails.validity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-violet-300 font-medium">Date & Time:</span>
                      <span className="text-white font-bold">{paymentDetails.date} {paymentDetails.time}</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex space-x-3">
                  <button
                    onClick={downloadReceipt}
                    className="flex-1 flex items-center justify-center space-x-2 py-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl text-white font-bold hover:scale-105 transition-transform"
                  >
                    <Download className="h-5 w-5" />
                    <span>DOWNLOAD</span>
                  </button>
                  <button
                    onClick={() => setSuccess(false)}
                    className="flex-1 py-3 bg-violet-600 hover:bg-violet-700 rounded-2xl text-white font-bold transition-colors"
                  >
                    CLOSE
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  )
}

export default RechargePage
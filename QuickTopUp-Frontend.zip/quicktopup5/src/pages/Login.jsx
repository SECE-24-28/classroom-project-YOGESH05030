import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { useTheme } from '../context/ThemeContext'
import { motion } from 'framer-motion'
import { Zap, Mail, Lock, Palette, UserCheck, Users, Shield } from 'lucide-react'

const Login = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loginType, setLoginType] = useState('user')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  
  const { login, user } = useAuth()
  const { theme, nextTheme } = useTheme()
  const navigate = useNavigate()

  useEffect(() => {
    if (user) {
      navigate(user.role === 'admin' ? '/admin' : '/user')
    }
  }, [user, navigate])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    const result = login(email, password)
    
    if (result.success) {
      navigate(result.user.role === 'admin' ? '/admin' : '/user')
    } else {
      setError(result.message)
    }
    
    setLoading(false)
  }

  const fillCredentials = (type) => {
    if (type === 'admin') {
      setEmail('admin@quicktopup.com')
      setPassword('admin123')
      setLoginType('admin')
    } else {
      setEmail('user1@topup.com')
      setPassword('user123')
      setLoginType('user')
    }
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.bg} flex items-center justify-center p-4 relative overflow-hidden`}>
      {/* Background Image */}
      <div className="absolute inset-0">
        <img 
          src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=1920&h=1080&fit=crop&crop=center" 
          alt="Mobile recharge background" 
          className="w-full h-full object-cover opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/80 via-purple-900/80 to-blue-900/80"></div>
      </div>
      {/* Animated Background */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      <button
        onClick={nextTheme}
        className={`absolute top-6 right-6 p-3 bg-slate-800/50 backdrop-blur-xl border ${theme.border} rounded-2xl hover:bg-slate-700/50 transition-all z-10`}
      >
        <Palette className={`h-6 w-6 ${theme.text}`} />
      </button>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative w-full max-w-md z-10"
      >
        <div className={`bg-gradient-to-br ${theme.card} backdrop-blur-2xl border-2 ${theme.border} rounded-3xl p-8 shadow-2xl`}>
          <div className="text-center mb-8">
            <motion.div 
              className="flex justify-center mb-6"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ duration: 0.8, type: "spring" }}
            >
              <div className="relative">
                <div className={`p-4 bg-gradient-to-r ${theme.accent} rounded-3xl shadow-lg`}>
                  <Zap className="h-12 w-12 text-white" />
                </div>
                <div className={`absolute -inset-1 bg-gradient-to-r ${theme.accent} rounded-3xl blur opacity-30 animate-pulse`}></div>
              </div>
            </motion.div>
            
            <motion.h1 
              className={`text-4xl font-black bg-gradient-to-r ${theme.accent} bg-clip-text text-transparent mb-3`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              QuickTopUp
            </motion.h1>
            <motion.p 
              className={`${theme.text} text-lg font-medium`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              Next-Gen Recharge Platform
            </motion.p>
          </div>

          <motion.div 
            className={`flex mb-8 p-1 bg-slate-700/50 rounded-2xl border ${theme.border}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <button
              type="button"
              onClick={() => fillCredentials('user')}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-xl transition-all duration-300 ${
                loginType === 'user'
                  ? `bg-gradient-to-r ${theme.accent} text-white shadow-lg scale-105`
                  : `${theme.text} hover:text-white hover:bg-slate-600/50`
              }`}
            >
              <Users className="h-5 w-5" />
              <span className="font-bold">USER</span>
            </button>
            <button
              type="button"
              onClick={() => fillCredentials('admin')}
              className={`flex-1 flex items-center justify-center space-x-2 py-3 px-4 rounded-xl transition-all duration-300 ${
                loginType === 'admin'
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg scale-105'
                  : `${theme.text} hover:text-white hover:bg-slate-600/50`
              }`}
            >
              <UserCheck className="h-5 w-5" />
              <span className="font-bold">ADMIN</span>
            </button>
          </motion.div>

          <motion.form 
            onSubmit={handleSubmit} 
            className="space-y-6"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            <div className="relative">
              <Mail className={`absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 ${theme.text}`} />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full pl-12 pr-4 py-4 bg-slate-700/50 border-2 ${theme.border} rounded-2xl text-white placeholder-slate-400 focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 transition-all`}
                placeholder="Email Address"
                required
              />
            </div>

            <div className="relative">
              <Lock className={`absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 ${theme.text}`} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`w-full pl-12 pr-4 py-4 bg-slate-700/50 border-2 ${theme.border} rounded-2xl text-white placeholder-slate-400 focus:border-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/20 transition-all`}
                placeholder="Password"
                required
              />
            </div>

            {error && (
              <motion.div 
                className="p-4 bg-red-500/20 border border-red-500/30 rounded-2xl text-red-300 text-center font-medium"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
              >
                <Shield className="h-5 w-5 inline mr-2" />
                {error}
              </motion.div>
            )}

            <button
              type="submit"
              disabled={loading}
              className={`w-full py-4 px-6 bg-gradient-to-r ${theme.accent} hover:from-cyan-600 hover:via-blue-600 hover:to-purple-600 text-white font-bold rounded-2xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:scale-105 relative overflow-hidden`}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500 to-cyan-500 opacity-0 hover:opacity-20 transition-opacity"></div>
              {loading ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                  <span>AUTHENTICATING...</span>
                </div>
              ) : (
                <span className="relative z-10">SIGN IN</span>
              )}
            </button>
          </motion.form>

          <motion.div 
            className="mt-8 text-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <div className={`text-sm ${theme.text}`}>
              <p className={`mb-3 font-bold ${theme.text}`}>DEMO CREDENTIALS</p>
              <div className={`space-y-2 bg-slate-700/30 rounded-2xl p-4 border ${theme.border}`}>
                <p><span className="font-bold text-purple-400">ADMIN:</span> admin@quicktopup.com / admin123</p>
                <p><span className={`font-bold ${theme.text}`}>USER:</span> user1@topup.com / user123</p>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  )
}

export default Login
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { History, Calendar, Smartphone, CreditCard, Filter, Download, Search } from 'lucide-react'
import Navbar from '../components/Navbar'
import { rechargesAPI } from '../api/mockapi'
import { useAuth } from '../context/AuthContext'

const RechargeHistory = () => {
  const { user } = useAuth()
  const [recharges, setRecharges] = useState([])
  const [filteredRecharges, setFilteredRecharges] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => {
    fetchRecharges()
  }, [user])

  useEffect(() => {
    filterRecharges()
  }, [recharges, filter, searchTerm])

  const fetchRecharges = async () => {
    try {
      let response
      if (user.role === 'admin') {
        try {
          response = await rechargesAPI.getAll()
        } catch (error) {
          const allRecharges = JSON.parse(localStorage.getItem('quicktopup_recharges') || '[]')
          response = { data: allRecharges }
        }
      } else {
        try {
          response = await rechargesAPI.getByUser(user.email)
        } catch (error) {
          const allRecharges = JSON.parse(localStorage.getItem('quicktopup_recharges') || '[]')
          response = { data: allRecharges.filter(r => r.userEmail === user.email) }
        }
      }
      setRecharges(response.data.sort((a, b) => new Date(b.date) - new Date(a.date)))
    } catch (error) {
      console.error('Error fetching recharges:', error)
    } finally {
      setLoading(false)
    }
  }

  const filterRecharges = () => {
    let filtered = [...recharges]

    if (filter !== 'all') {
      const days = parseInt(filter)
      const cutoffDate = new Date()
      cutoffDate.setDate(cutoffDate.getDate() - days)
      filtered = filtered.filter(recharge => new Date(recharge.date) >= cutoffDate)
    }

    if (searchTerm) {
      filtered = filtered.filter(recharge =>
        recharge.mobile?.includes(searchTerm) ||
        recharge.planTitle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recharge.userEmail?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recharge.provider?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    setFilteredRecharges(filtered)
  }

  const getTotalAmount = () => {
    return filteredRecharges.reduce((sum, recharge) => sum + (recharge.amount || 0), 0)
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const downloadHistory = () => {
    const csvContent = [
      ['Date', 'Mobile', 'Provider', 'Plan', 'Amount', 'Validity', 'Transaction ID', 'User'].join(','),
      ...filteredRecharges.map(r => [
        r.date,
        r.mobile,
        r.provider || 'N/A',
        r.planTitle,
        r.amount,
        r.validity,
        r.transactionId || 'N/A',
        r.userEmail
      ].join(','))
    ].join('\n')
    
    const blob = new Blob([csvContent], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `Recharge_History_${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin"></div>
            <History className="absolute inset-0 m-auto h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header */}
          <div className="text-center mb-12">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center space-x-4 mb-6"
            >
              <div className="relative">
                <div className="p-4 bg-gradient-to-r from-pink-500 via-purple-500 to-violet-500 rounded-full shadow-2xl">
                  <History className="h-10 w-10 text-white" />
                </div>
                <div className="absolute -inset-2 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full blur opacity-40 animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-5xl font-black bg-gradient-to-r from-pink-400 via-purple-400 to-violet-400 bg-clip-text text-transparent">
                  {user.role === 'admin' ? 'ALL RECHARGE HISTORY' : 'MY RECHARGE HISTORY'}
                </h1>
                <p className="text-purple-300 text-xl font-bold mt-2">
                  {user.role === 'admin' ? 'View all user transactions' : 'Your transaction history'}
                </p>
              </div>
            </motion.div>
          </div>

          {/* Filters and Stats */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
            <div className="lg:col-span-3 bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <label className="block text-violet-300 font-bold mb-2">
                    Search Transactions
                  </label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-violet-400" />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-violet-900/40 border-2 border-violet-400/40 rounded-2xl text-white placeholder-violet-400 focus:border-pink-400 focus:outline-none"
                      placeholder="Search by mobile, plan, email, provider..."
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-violet-300 font-bold mb-2">
                    Filter by Date
                  </label>
                  <div className="relative">
                    <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-violet-400" />
                    <select
                      value={filter}
                      onChange={(e) => setFilter(e.target.value)}
                      className="pl-10 pr-8 py-3 bg-violet-900/40 border-2 border-violet-400/40 rounded-2xl text-white focus:border-pink-400 focus:outline-none"
                    >
                      <option value="all">All Time</option>
                      <option value="7">Last 7 Days</option>
                      <option value="30">Last 30 Days</option>
                      <option value="90">Last 90 Days</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl p-6">
              <div className="text-center">
                <p className="text-violet-300 font-bold mb-2">Total Amount</p>
                <p className="text-3xl font-black text-green-400">₹{getTotalAmount().toLocaleString()}</p>
                <p className="text-violet-400 text-sm">{filteredRecharges.length} transactions</p>
                <button
                  onClick={downloadHistory}
                  className="mt-4 flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl text-white font-bold hover:scale-105 transition-transform mx-auto"
                >
                  <Download className="h-4 w-4" />
                  <span>Export</span>
                </button>
              </div>
            </div>
          </div>

          {/* Recharge List */}
          {filteredRecharges.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl p-12 text-center"
            >
              <History className="h-16 w-16 text-violet-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">No Recharges Found</h3>
              <p className="text-violet-300">
                {searchTerm || filter !== 'all' ? 'Try adjusting your filters' : 'No recharge history available'}
              </p>
            </motion.div>
          ) : (
            <div className="space-y-4">
              {filteredRecharges.map((recharge, index) => (
                <motion.div
                  key={recharge.id || index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="bg-gradient-to-br from-violet-800/60 to-fuchsia-800/60 backdrop-blur-xl border-2 border-violet-400/40 rounded-3xl p-6 hover:border-pink-400/50 transition-all"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-start space-x-4">
                      <div className="p-3 bg-gradient-to-r from-pink-500 to-violet-500 rounded-2xl">
                        <Smartphone className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="text-xl font-black text-white">
                            {recharge.planTitle}
                          </h3>
                          <span className="text-3xl font-black text-green-400">
                            ₹{recharge.amount}
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-4 text-sm text-violet-300">
                          <div className="flex items-center space-x-1">
                            <Smartphone className="h-4 w-4" />
                            <span>{recharge.mobile}</span>
                          </div>
                          {recharge.provider && (
                            <div className="px-2 py-1 bg-violet-900/40 rounded-lg border border-violet-400/30">
                              <span className="font-bold">{recharge.provider}</span>
                            </div>
                          )}
                          {user.role === 'admin' && (
                            <div className="flex items-center space-x-1">
                              <CreditCard className="h-4 w-4" />
                              <span>{recharge.userEmail}</span>
                            </div>
                          )}
                          <div className="flex items-center space-x-1">
                            <Calendar className="h-4 w-4" />
                            <span>{formatDate(recharge.date)}</span>
                          </div>
                          {recharge.transactionId && (
                            <div className="px-2 py-1 bg-green-500/20 rounded-lg border border-green-400/30">
                              <span className="text-green-300 font-bold text-xs">ID: {recharge.transactionId}</span>
                            </div>
                          )}
                        </div>
                        <p className="text-sm text-violet-400 mt-1">
                          Validity: {recharge.validity}
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  )
}

export default RechargeHistory
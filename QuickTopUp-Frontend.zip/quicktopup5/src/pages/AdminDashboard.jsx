import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Settings, History, Users, TrendingUp, Zap, BarChart3, Shield, Crown, Activity, Calendar, DollarSign, Smartphone } from 'lucide-react'
import Navbar from '../components/Navbar'
import { plansAPI, rechargesAPI, localPlansAPI } from '../api/mockapi'
import { useTheme } from '../context/ThemeContext'

const AdminDashboard = () => {
  const { theme } = useTheme()
  const [stats, setStats] = useState({
    totalPlans: 0,
    totalRecharges: 0,
    totalRevenue: 0,
    activeUsers: 3,
    todayRecharges: 0,
    monthlyGrowth: 15.5
  })
  const [recentActivity, setRecentActivity] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStats()
  }, [])

  const fetchStats = async () => {
    try {
      let plansData, rechargesData
      
      try {
        const [plansRes, rechargesRes] = await Promise.all([
          plansAPI.getAll(),
          rechargesAPI.getAll()
        ])
        plansData = plansRes.data
        rechargesData = rechargesRes.data
      } catch (error) {
        plansData = localPlansAPI.getAll().data
        rechargesData = JSON.parse(localStorage.getItem('quicktopup_recharges') || '[]')
      }

      const totalRevenue = rechargesData.reduce((sum, recharge) => sum + (recharge.amount || 0), 0)
      const today = new Date().toISOString().split('T')[0]
      const todayRecharges = rechargesData.filter(r => r.date === today).length

      setStats({
        totalPlans: plansData.length,
        totalRecharges: rechargesData.length,
        totalRevenue,
        activeUsers: 3,
        todayRecharges,
        monthlyGrowth: 15.5
      })

      setRecentActivity(rechargesData.slice(-5).reverse())
    } catch (error) {
      console.error('Error fetching stats:', error)
    } finally {
      setLoading(false)
    }
  }

  const dashboardCards = [
    {
      title: 'Plan Management',
      description: 'Create, edit, and manage all recharge plans',
      icon: Settings,
      link: '/admin/plans',
      gradient: theme.accent,
      stats: `${stats.totalPlans} Active Plans`,
      bgGlow: 'bg-cyan-500/10',
      features: ['Create Plans', 'Edit Plans', 'Delete Plans', 'Plan Analytics']
    },
    {
      title: 'Transaction History',
      description: 'Monitor all user recharge transactions',
      icon: History,
      link: '/admin/history',
      gradient: 'from-green-500 via-emerald-500 to-teal-500',
      stats: `${stats.totalRecharges} Total Transactions`,
      bgGlow: 'bg-green-500/10',
      features: ['View All Transactions', 'Filter by Date', 'Export Reports', 'User Analytics']
    }
  ]

  const statsCards = [
    {
      title: 'Total Revenue',
      value: `₹${stats.totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      gradient: 'from-green-500 to-emerald-500',
      bgGlow: 'bg-green-500/10',
      change: '+12.5%',
      changeType: 'positive'
    },
    {
      title: 'Active Plans',
      value: stats.totalPlans,
      icon: Zap,
      gradient: theme.accent,
      bgGlow: 'bg-cyan-500/10',
      change: '+3',
      changeType: 'positive'
    },
    {
      title: 'Total Recharges',
      value: stats.totalRecharges,
      icon: BarChart3,
      gradient: 'from-purple-500 to-pink-500',
      bgGlow: 'bg-purple-500/10',
      change: '+8.2%',
      changeType: 'positive'
    },
    {
      title: 'Today\'s Recharges',
      value: stats.todayRecharges,
      icon: Activity,
      gradient: 'from-orange-500 to-red-500',
      bgGlow: 'bg-orange-500/10',
      change: '+5',
      changeType: 'positive'
    },
    {
      title: 'Active Users',
      value: stats.activeUsers,
      icon: Users,
      gradient: 'from-indigo-500 to-purple-500',
      bgGlow: 'bg-indigo-500/10',
      change: 'Stable',
      changeType: 'neutral'
    },
    {
      title: 'Monthly Growth',
      value: `${stats.monthlyGrowth}%`,
      icon: TrendingUp,
      gradient: 'from-pink-500 to-rose-500',
      bgGlow: 'bg-pink-500/10',
      change: '+2.1%',
      changeType: 'positive'
    }
  ]

  if (loading) {
    return (
      <div className={`min-h-screen bg-gradient-to-br ${theme.bg}`}>
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-24 h-24 border-4 border-purple-200 border-t-purple-500 rounded-full animate-spin"></div>
            <Shield className="absolute inset-0 m-auto h-10 w-10 text-purple-400" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.bg}`}>
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header with Background */}
          <div className="relative text-center mb-12 overflow-hidden rounded-3xl">
            <div className={`absolute inset-0 bg-gradient-to-r from-slate-900/90 via-purple-900/90 to-blue-900/90`}></div>
            <div className="absolute inset-0 opacity-25">
              <img 
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=1200&h=300&fit=crop&crop=center" 
                alt="Data analytics dashboard" 
                className="w-full h-full object-cover"
              />
            </div>
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="relative z-10 py-16 px-8"
            >
              <div className="inline-flex items-center space-x-4 mb-6">
                <div className="relative">
                  <div className={`p-4 bg-gradient-to-r ${theme.accent} rounded-full shadow-2xl`}>
                    <Crown className="h-12 w-12 text-white" />
                  </div>
                  <div className={`absolute -inset-1 bg-gradient-to-r ${theme.accent} rounded-full blur opacity-40 animate-pulse`}></div>
                </div>
                <div>
                  <h1 className={`text-6xl font-black bg-gradient-to-r ${theme.accent} bg-clip-text text-transparent`}>
                    ADMIN CONTROL CENTER
                  </h1>
                  <p className={`${theme.text} text-xl font-bold mt-2`}>Complete System Management Dashboard</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {statsCards.map((stat, index) => (
              <motion.div
                key={stat.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`relative p-6 bg-gradient-to-br ${theme.card} backdrop-blur-2xl border-2 ${theme.border} rounded-3xl hover:border-purple-300/50 transition-all duration-300 group overflow-hidden hover:scale-105`}
              >
                <div className={`absolute inset-0 ${stat.bgGlow} opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl`}></div>
                
                <div className="relative">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 bg-gradient-to-r ${stat.gradient} rounded-2xl shadow-lg`}>
                      <stat.icon className="h-8 w-8 text-white" />
                    </div>
                    <div className={`px-3 py-1 rounded-xl text-sm font-bold ${
                      stat.changeType === 'positive' ? 'bg-green-500/20 text-green-300' :
                      stat.changeType === 'negative' ? 'bg-red-500/20 text-red-300' :
                      'bg-gray-500/20 text-gray-300'
                    }`}>
                      {stat.change}
                    </div>
                  </div>
                  
                  <p className={`${theme.text} text-sm font-medium mb-2`}>{stat.title}</p>
                  <p className="text-4xl font-black text-white">{stat.value}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Main Action Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            {dashboardCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                className="group relative overflow-hidden"
              >
                <Link
                  to={card.link}
                  className={`block p-8 bg-gradient-to-br ${theme.card} backdrop-blur-2xl border-2 ${theme.border} rounded-3xl hover:border-purple-300/50 transition-all duration-300 hover:scale-105`}
                >
                  <div className={`absolute inset-0 ${card.bgGlow} opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl`}></div>
                  
                  <div className="relative">
                    <div className="flex items-center justify-between mb-6">
                      <div className={`p-4 bg-gradient-to-r ${card.gradient} rounded-2xl shadow-lg`}>
                        <card.icon className="h-10 w-10 text-white" />
                      </div>
                      <span className={`px-4 py-2 bg-purple-700/50 rounded-2xl ${theme.text} font-bold text-sm border-2 ${theme.border}`}>
                        {card.stats}
                      </span>
                    </div>
                    
                    <h3 className={`text-3xl font-black text-white mb-4 group-hover:${theme.text} transition-colors`}>
                      {card.title}
                    </h3>
                    <p className={`${theme.text} leading-relaxed mb-6 text-lg`}>{card.description}</p>
                    
                    <div className="grid grid-cols-2 gap-3 mb-6">
                      {card.features.map((feature, idx) => (
                        <div key={idx} className={`flex items-center space-x-2 ${theme.text}`}>
                          <div className={`w-2 h-2 bg-gradient-to-r ${theme.accent} rounded-full`}></div>
                          <span className="text-sm font-medium">{feature}</span>
                        </div>
                      ))}
                    </div>
                    
                    <div className={`flex items-center ${theme.text} font-bold text-lg`}>
                      <span>Access Panel</span>
                      <svg className="w-6 h-6 ml-2 group-hover:translate-x-2 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
            className={`bg-gradient-to-br ${theme.card} backdrop-blur-2xl border-2 ${theme.border} rounded-3xl p-8`}
          >
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-3">
                <Activity className={`h-8 w-8 ${theme.text}`} />
                <h2 className="text-3xl font-black text-white">RECENT ACTIVITY</h2>
              </div>
              <Link
                to="/admin/history"
                className={`px-6 py-3 bg-gradient-to-r ${theme.accent} rounded-2xl text-white font-bold hover:scale-105 transition-transform`}
              >
                View All
              </Link>
            </div>
            
            <div className="space-y-4">
              {recentActivity.length > 0 ? recentActivity.map((activity, index) => (
                <div key={index} className={`flex items-center justify-between p-4 bg-purple-900/30 rounded-2xl border-2 ${theme.border}`}>
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl">
                      <Smartphone className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="text-white font-bold">{activity.planTitle}</p>
                      <p className={`${theme.text} text-sm`}>{activity.userEmail} • {activity.mobile}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-black text-green-400">₹{activity.amount}</p>
                    <p className={`${theme.text} text-sm`}>{activity.date}</p>
                  </div>
                </div>
              )) : (
                <div className="text-center py-8">
                  <Activity className={`h-16 w-16 ${theme.text} mx-auto mb-4`} />
                  <p className={`${theme.text} text-lg`}>No recent activity</p>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}

export default AdminDashboard
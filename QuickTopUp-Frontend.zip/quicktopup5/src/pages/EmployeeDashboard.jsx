import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Zap, History, CreditCard, TrendingUp, Smartphone, User, ArrowRight, Clock, Shield } from 'lucide-react'
import Navbar from '../components/Navbar'
import { plansAPI, rechargesAPI, localPlansAPI } from '../api/mockapi'
import { useAuth } from '../context/AuthContext'
import { useTheme } from '../context/ThemeContext'

const EmployeeDashboard = () => {
  const { user } = useAuth()
  const { theme } = useTheme()
  const [stats, setStats] = useState({
    totalPlans: 0,
    myRecharges: 0,
    totalSpent: 0
  })
  const [recentPlans, setRecentPlans] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [user])

  const fetchData = async () => {
    try {
      let plansData, rechargesData
      
      try {
        const [plansRes, rechargesRes] = await Promise.all([
          plansAPI.getAll(),
          rechargesAPI.getByUser(user.email)
        ])
        plansData = plansRes.data
        rechargesData = rechargesRes.data
      } catch (error) {
        plansData = localPlansAPI.getAll().data
        const allRecharges = JSON.parse(localStorage.getItem('quicktopup_recharges') || '[]')
        rechargesData = allRecharges.filter(r => r.userEmail === user.email)
      }

      const totalSpent = rechargesData.reduce((sum, recharge) => sum + (recharge.amount || 0), 0)

      setStats({
        totalPlans: plansData.length,
        myRecharges: rechargesData.length,
        totalSpent
      })

      setRecentPlans(plansData.slice(0, 6))
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }

  const dashboardCards = [
    {
      title: 'Browse Plans',
      description: 'Explore all available recharge plans',
      icon: Smartphone,
      link: '/user/recharge',
      gradient: 'from-pink-500 via-purple-500 to-violet-500',
      stats: `${stats.totalPlans} Available`,
      bgGlow: 'bg-pink-500/10'
    },
    {
      title: 'My History',
      description: 'View your recharge transaction history',
      icon: History,
      link: '/user/history',
      gradient: 'from-green-500 via-emerald-500 to-teal-500',
      stats: `${stats.myRecharges} Recharges`,
      bgGlow: 'bg-green-500/10'
    }
  ]

  const statsCards = [
    {
      title: 'Available Plans',
      value: stats.totalPlans,
      icon: Smartphone,
      gradient: 'from-pink-500 to-violet-500',
      bgGlow: 'bg-pink-500/10'
    },
    {
      title: 'My Recharges',
      value: stats.myRecharges,
      icon: CreditCard,
      gradient: 'from-green-500 to-emerald-500',
      bgGlow: 'bg-green-500/10'
    },
    {
      title: 'Total Spent',
      value: `₹${stats.totalSpent}`,
      icon: TrendingUp,
      gradient: 'from-purple-500 to-fuchsia-500',
      bgGlow: 'bg-purple-500/10'
    }
  ]

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-fuchsia-900">
        <Navbar />
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-20 h-20 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin"></div>
            <User className="absolute inset-0 m-auto h-8 w-8 text-purple-400" />
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={`min-h-screen bg-gradient-to-br ${theme.bg}`}>
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Header */}
          <div className="text-center mb-12">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center space-x-4 mb-6"
            >
              <div className="relative">
                <div className="p-4 bg-gradient-to-r from-pink-500 via-purple-500 to-violet-500 rounded-full shadow-2xl">
                  <User className="h-10 w-10 text-white" />
                </div>
                <div className="absolute -inset-2 bg-gradient-to-r from-pink-500 to-violet-500 rounded-full blur opacity-40 animate-pulse"></div>
              </div>
              <div>
                <h1 className="text-5xl font-black bg-gradient-to-r from-pink-400 via-purple-400 to-violet-400 bg-clip-text text-transparent">
                  Welcome, {user?.name}
                </h1>
                <p className="text-purple-300 text-xl font-bold mt-2">User Dashboard</p>
              </div>
            </motion.div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {statsCards.map((stat, index) => (
              <motion.div
                key={stat.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`relative p-6 bg-gradient-to-br ${theme.card} backdrop-blur-xl border-2 ${theme.border} rounded-3xl hover:border-pink-400/50 transition-all duration-300 group overflow-hidden hover:scale-105`}
              >
                <div className={`absolute inset-0 ${stat.bgGlow} opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl`}></div>
                
                <div className="relative flex items-center justify-between">
                  <div>
                    <p className={`${theme.text} text-sm font-medium mb-2`}>{stat.title}</p>
                    <p className="text-4xl font-black text-white">{stat.value}</p>
                  </div>
                  <div className={`p-3 bg-gradient-to-r ${stat.gradient} rounded-2xl shadow-lg`}>
                    <stat.icon className="h-8 w-8 text-white" />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Action Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {dashboardCards.map((card, index) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                className="group relative overflow-hidden"
              >
                <Link
                  to={card.link}
                  className={`block p-8 bg-gradient-to-br ${theme.card} backdrop-blur-xl border-2 ${theme.border} rounded-3xl hover:border-pink-400/50 transition-all duration-300 hover:scale-105`}
                >
                  <div className={`absolute inset-0 ${card.bgGlow} opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl`}></div>
                  
                  <div className="relative">
                    <div className="flex items-center justify-between mb-6">
                      <div className={`p-4 bg-gradient-to-r ${card.gradient} rounded-2xl shadow-lg`}>
                        <card.icon className="h-8 w-8 text-white" />
                      </div>
                      <span className={`px-4 py-2 bg-violet-700/50 rounded-2xl ${theme.text} font-bold text-sm border-2 ${theme.border}`}>
                        {card.stats}
                      </span>
                    </div>
                    
                    <h3 className="text-2xl font-black text-white mb-3 group-hover:text-pink-300 transition-colors">
                      {card.title}
                    </h3>
                    <p className={`${theme.text} leading-relaxed`}>{card.description}</p>
                    
                    <div className="mt-6 flex items-center text-pink-300 font-bold">
                      <span>Access Now</span>
                      <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Quick Plans Preview */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className={`bg-gradient-to-br ${theme.card} backdrop-blur-xl border-2 ${theme.border} rounded-3xl p-8`}
          >
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-3">
                <Zap className={`h-8 w-8 ${theme.text}`} />
                <h2 className="text-2xl font-black text-white">POPULAR PLANS</h2>
              </div>
              <Link
                to="/employee/recharge"
                className={`px-6 py-3 bg-gradient-to-r ${theme.accent} rounded-2xl text-white font-bold hover:scale-105 transition-transform`}
              >
                View All Plans
              </Link>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentPlans.map((plan, index) => (
                <motion.div
                  key={plan.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.3, delay: 0.6 + index * 0.1 }}
                  className={`p-6 bg-violet-900/40 border-2 ${theme.border} rounded-2xl hover:border-pink-400/40 transition-all group`}
                >
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="p-2 bg-gradient-to-r from-pink-500 to-violet-500 rounded-xl">
                      <Zap className="h-5 w-5 text-white" />
                    </div>
                    <h3 className="font-bold text-white group-hover:text-pink-400 transition-colors">{plan.title}</h3>
                  </div>
                  
                  <div className="space-y-2">
                    <p className="text-3xl font-black bg-gradient-to-r from-pink-400 to-violet-400 bg-clip-text text-transparent">
                      ₹{plan.amount}
                    </p>
                    <div className={`flex items-center space-x-2 ${theme.text}`}>
                      <Clock className="h-4 w-4" />
                      <span className="text-sm font-medium">{plan.validity}</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <Shield className="h-4 w-4 mt-0.5 text-violet-400" />
                      <p className={`text-xs ${theme.text} leading-relaxed`}>{plan.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  )
}

export default EmployeeDashboard
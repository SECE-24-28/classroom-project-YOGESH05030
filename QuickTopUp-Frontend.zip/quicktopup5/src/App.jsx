import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { ThemeProvider } from './context/ThemeContext'
import Login from './pages/Login'
import AdminDashboard from './pages/AdminDashboard'
import UserDashboard from './pages/UserDashboard'
import ManagePlans from './pages/ManagePlans'
import RechargeHistory from './pages/RechargeHistory'
import RechargePage from './pages/RechargePage'
import About from './pages/About'
import ProtectedRoute from './components/ProtectedRoute'

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Router>
          <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/" element={<Navigate to="/login" replace />} />
              
              <Route path="/admin" element={
                <ProtectedRoute role="admin">
                  <AdminDashboard />
                </ProtectedRoute>
              } />
              
              <Route path="/admin/plans" element={
                <ProtectedRoute role="admin">
                  <ManagePlans />
                </ProtectedRoute>
              } />
              
              <Route path="/admin/history" element={
                <ProtectedRoute role="admin">
                  <RechargeHistory />
                </ProtectedRoute>
              } />
              
              <Route path="/user" element={
                <ProtectedRoute role="user">
                  <UserDashboard />
                </ProtectedRoute>
              } />
              
              <Route path="/user/recharge" element={
                <ProtectedRoute role="user">
                  <RechargePage />
                </ProtectedRoute>
              } />
              
              <Route path="/user/history" element={
                <ProtectedRoute role="user">
                  <RechargeHistory />
                </ProtectedRoute>
              } />
              
              <Route path="/about" element={<About />} />
            </Routes>
          </div>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  )
}

export default App
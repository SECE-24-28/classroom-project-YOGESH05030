# QuickTopUp - Mobile Recharge Platform

A complete React + Vite + Tailwind CSS mobile recharge platform with admin and user dashboards.

## 🚀 Features

### Admin Features
- **Admin Login**: admin@quicktopup.com / admin123
- **Plan Management**: Create, edit, delete recharge plans
- **Recharge History**: View all user recharge transactions
- **Dashboard**: Statistics and overview

### User Features
- **User Login**: user1@topup.com / user123 (user2, user3 also available)
- **Browse Plans**: View all available recharge plans
- **Mobile Recharge**: Recharge with mobile number validation
- **Personal History**: View personal recharge history

### Technical Features
- ✅ React + Vite + Tailwind CSS
- ✅ Dark Mode with persistence
- ✅ Glassmorphism UI design
- ✅ Framer Motion animations
- ✅ MockAPI integration for persistent data
- ✅ Role-based authentication
- ✅ Mobile number validation
- ✅ Responsive design
- ✅ LocalStorage session management

## 🛠️ Setup Instructions

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure MockAPI
1. Go to [MockAPI.io](https://mockapi.io)
2. Create a new project
3. Create 3 resources:
   - **plans**: title (string), amount (number), validity (string), description (string)
   - **recharges**: userEmail (string), mobile (string), planTitle (string), amount (number), validity (string), date (string)
   - **users**: name (string), email (string), role (string)

4. Update the BASE_URL in `src/api/mockapi.js` with your MockAPI endpoint

### 3. Run the Application
```bash
npm run dev
```

## 📱 Demo Credentials

### Admin Login
- **Email**: admin@quicktopup.com
- **Password**: admin123

### User Login
- **Email**: user1@topup.com / user2@topup.com / user3@topup.com
- **Password**: user123

## 🏗️ Project Structure

```
src/
├── components/
│   ├── Navbar.jsx
│   └── ProtectedRoute.jsx
├── context/
│   ├── AuthContext.jsx
│   └── ThemeContext.jsx
├── pages/
│   ├── Login.jsx
│   ├── AdminDashboard.jsx
│   ├── UserDashboard.jsx
│   ├── ManagePlans.jsx
│   ├── RechargePage.jsx
│   └── RechargeHistory.jsx
├── api/
│   └── mockapi.js
├── hooks/
│   ├── usePlans.js
│   └── useRecharges.js
└── App.jsx
```

## 🎨 UI Features

- **Glassmorphism Design**: Modern glass-like cards and components
- **Dark Mode**: Toggle between light and dark themes
- **Responsive Layout**: Works on all device sizes
- **Smooth Animations**: Framer Motion powered transitions
- **Gradient Backgrounds**: Beautiful gradient color schemes

## 🔧 Key Functionalities

### Authentication
- Hardcoded user credentials
- Role-based access control
- Session persistence with localStorage

### Plan Management (Admin)
- CRUD operations for recharge plans
- Auto-seeding of 20 default plans
- Real-time updates

### Recharge System (User)
- Mobile number validation (10 digits, starts with 6-9)
- Plan selection interface
- Instant recharge processing
- Success notifications

### History Tracking
- Persistent storage in MockAPI
- Filter by date ranges
- Search functionality
- Admin can view all transactions
- Users see only their transactions

## 🚀 Deployment Ready

The project is fully configured and ready for deployment. All data is stored in MockAPI, ensuring persistence across sessions and deployments.

## 📦 Dependencies

- **React 18**: Modern React with hooks
- **React Router**: Client-side routing
- **Tailwind CSS**: Utility-first CSS framework
- **Axios**: HTTP client for API calls
- **Framer Motion**: Animation library
- **Lucide React**: Beautiful icons

## 🔒 Security Features

- Input validation for mobile numbers
- Role-based route protection
- Secure authentication flow
- Data persistence in external API

---

**Ready to use!** Just update the MockAPI URL and run `npm install && npm run dev`
# MockAPI Setup Guide

## Step 1: Create MockAPI Account
1. Go to [https://mockapi.io](https://mockapi.io)
2. Sign up for a free account
3. Create a new project

## Step 2: Create Resources

### Resource 1: plans
**Endpoint**: `/plans`
**Fields**:
- `title` (string) - Plan name
- `amount` (number) - Price in rupees
- `validity` (string) - Validity period
- `description` (string) - Plan description

### Resource 2: recharges
**Endpoint**: `/recharges`
**Fields**:
- `userEmail` (string) - Employee email
- `mobile` (string) - Mobile number
- `planTitle` (string) - Selected plan name
- `amount` (number) - Recharge amount
- `validity` (string) - Plan validity
- `date` (string) - Recharge date

### Resource 3: users
**Endpoint**: `/users`
**Fields**:
- `name` (string) - User full name
- `email` (string) - User email
- `role` (string) - "admin" or "employee"

## Step 3: Update API URL
1. Copy your MockAPI project URL (e.g., `https://675b8b4071933a4e885433b8.mockapi.io`)
2. Update the `BASE_URL` in `src/api/mockapi.js`

## Step 4: Sample Data
The application will automatically populate 20 sample plans and 4 users when you first run it.

## Troubleshooting
- Ensure your MockAPI URL is correct
- Check that all resources are created with exact field names
- Verify your internet connection
- Check browser console for detailed error messages
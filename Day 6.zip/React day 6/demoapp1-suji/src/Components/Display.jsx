function Display()
{
    return(
    <div>
        <h1>React Learning....</h1>
    </div>
    );
}

export default Display;
import './App.css';
import Image from "./components/Image"
function App() {
  

  return (
    <>
      <div className="App">
        
        <Image />

      </div>
    </>
  )
}

export default App
document.getElementById("rechargeForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const mobile = document.getElementById("mobile").value;
    const operator = document.getElementById("operator").value;
    const plan = document.getElementById("plan").value;
    const message = document.getElementById("message");

    if (mobile.length != 10) {
        message.style.color = "red";
        message.innerHTML = " Invalid Mobile Number!";
        return;
    }

    if (operator === "" || plan === "") {
        message.style.color = "red";
        message.innerHTML = " Please select Operator and Plan!";
        return;
    }

    message.style.color = "green";
    message.innerHTML = `Recharge of ${plan} successful for ${mobile}`;
});
